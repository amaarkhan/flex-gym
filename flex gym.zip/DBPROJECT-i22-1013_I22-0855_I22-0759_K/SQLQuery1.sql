
create Database FlexTrainerInserted 
use FlexTrainerInserted

---------------------------------------------------------------------------ADMIN

CREATE TABLE Admin (
    AdminID INT PRIMARY KEY,
    Username VARCHAR(50) UNIQUE,
    Name VARCHAR(50),
    Email VARCHAR(100),
    Password VARCHAR(100),
    ContactNumber VARCHAR(20),
    Role VARCHAR(50)
);

INSERT INTO Admin (AdminID, Username, Name, Email, Password, ContactNumber, Role)
VALUES 
    (1, 'admin01', 'Mustafa', 'mustafak@gmail.com', '1234', '1234567890', 'Admin'),
    (2, 'admin02', 'Ali', 'ali@example.com', '1234', '12345', 'Admin'),
    (3, 'admin03', 'Sara', 'sara@example.com', '1234', '12346', 'Admin'),
    (4, 'admin04', 'Ahmed', 'ahmed@example.com', '1234', '12347', 'Admin'),
    (5, 'admin05', 'Ayesha', 'ayesha@example.com', '1234', '12348', 'Admin'),
    (6, 'admin06', 'Zainab', 'zainab@example.com', '1234', '12349', 'Admin'),
    (7, 'admin07', 'Bilal', 'bilal@example.com', '1234', '12350', 'Admin'),
    (8, 'admin08', 'Fatima', 'fatima@example.com', '1234', '12351', 'Admin'),
    (9, 'admin09', 'Imran', 'imran@example.com', '1234', '12352', 'Admin'),
    (10, 'admin10', 'Sadia', 'sadia@example.com', '1234', '12353', 'Admin'),
    (11, 'admin11', 'Kamran', 'kamran@example.com', '1234', '12354', 'Admin'),
    (12, 'admin12', 'Aisha', 'aisha@example.com', '1234', '12355', 'Admin'),
    (13, 'admin13', 'Asad', 'asad@example.com', '1234', '12356', 'Admin'),
    (14, 'admin14', 'Nida', 'nida@example.com', '1234', '12357', 'Admin'),
    (15, 'admin15', 'Yasir', 'yasir@example.com', '1234', '12358', 'Admin'),
    (16, 'admin16', 'Sana', 'sana@example.com', '1234', '12359', 'Admin'),
    (17, 'admin17', 'Aliya', 'aliya@example.com', '1234', '12360', 'Admin'),
    (18, 'admin18', 'Farhan', 'farhan@example.com', '1234', '12361', 'Admin'),
    (19, 'admin19', 'Raza', 'raza@example.com', '1234', '12362', 'Admin'),
    (20, 'admin20', 'Hina', 'hina@example.com', '1234', '12363', 'Admin');



---------------------------------------------------------------------------GYM

CREATE TABLE Gym (
    GymID INT PRIMARY KEY,
    OwnerID INT,
    Name VARCHAR(100),
    Location VARCHAR(100),
    ContactNumber VARCHAR(20),
    Email VARCHAR(100),
    Facilities VARCHAR(255),
    MembershipPlans VARCHAR(255),
    ActiveMembersCount INT,
    Rating FLOAT,
    Growth VARCHAR(50),
    FinancialPerformance VARCHAR(50),
    CustomerSatisfaction VARCHAR(50)
);

INSERT INTO Gym (GymID, OwnerID, Name, Location, ContactNumber, Email, Facilities, MembershipPlans, ActiveMembersCount, Rating, Growth, FinancialPerformance, CustomerSatisfaction)
VALUES
(1, 1, 'FitZone', 'lahore', '123-456-7890', 'ali@example.com', 'Gym, Cardio', 'Monthly, Yearly', 50, 4.5, 'Growing', 'Good', 'Good'),
(2, 2, 'HealthHub', 'pindi', '987-654-3210', 'sana@example.com', 'Gym, Aerobics', 'Monthly', 30, 4.0, 'Stable', 'Good', 'Good'),
(3, 1, 'IronGym', 'islambad', '123-456-7890', 'ali@example.com', 'Gym, Weightlifting', 'Monthly, Quarterly', 40, 4.2, 'Declining', 'Good', 'Good'),
(4, 2, 'PowerHouse', 'karachi', '987-654-3210', 'sana@example.com', 'Gym, CrossFit', 'Yearly', 25, 4.1, 'Growing', 'Good', 'Good'),
(5, 3, 'FitnessFusion', 'lahore', '123-456-7890', 'ali@example.com', 'Gym, Yoga', 'Monthly', 35, 4.3, 'Stable', 'Good', 'Good'),
(6, 4, 'MuscleMania', 'peshawar', '987-654-3210', 'sana@example.com', 'Gym, Pilates', 'Monthly', 20, 4.2, 'Declining', 'Good', 'Good'),
(7, 5, 'BodyBlast', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Zumba', 'Yearly', 45, 4.4, 'Growing', 'Good', 'Good'),
(8, 6, 'FlexFitness', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Spinning', 'Monthly', 30, 4.0, 'Stable', 'Good', 'Good'),
(9, 7, 'SweatStudio', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Bootcamp', 'Monthly', 40, 4.3, 'Growing', 'Good', 'Good'),
(10, 8, 'CoreCraze', 'pindi', '987-654-3210', 'sana@example.com', 'Gym, Martial Arts', 'Monthly', 25, 4.2, 'Stable', 'Good', 'Good'),
(11, 9, 'FitFusion', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, CrossFit', 'Monthly, Yearly', 35, 4.4, 'Declining', 'Good', 'Good'),
(12, 10, 'BodyBurn', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Cardio', 'Monthly', 40, 4.3, 'Growing', 'Good', 'Good'),
(13, 11, 'PulseFitness', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Aerobics', 'Yearly', 30, 4.1, 'Stable', 'Good', 'Good'),
(14, 12, 'StrengthZone', 'peshawar', '987-654-3210', 'sana@example.com', 'Gym, Weightlifting', 'Monthly', 20, 4.2, 'Declining', 'Good', 'Good'),
(15, 13, 'YogaYard', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Yoga', 'Monthly, Quarterly', 45, 4.5, 'Growing', 'Good', 'Good'),
(16, 14, 'PilatesPlace', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Pilates', 'Monthly', 30, 4.0, 'Stable', 'Good', 'Good'),
(17, 15, 'ZumbaZone', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Zumba', 'Yearly', 40, 4.3, 'Growing', 'Good', 'Good'),
(18, 16, 'SpinCity', 'pindi', '987-654-3210', 'sana@example.com', 'Gym, Spinning', 'Monthly', 25, 4.2, 'Stable', 'Good', 'Good'),
(19, 17, 'BootcampBase', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Bootcamp', 'Monthly', 35, 4.4, 'Declining', 'Good', 'Good'),
(20, 18, 'MartialArtsMania', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Martial Arts', 'Monthly', 40, 4.3, 'Growing', 'Good', 'Good'),
(21, 19, 'CrossFitCraze', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, CrossFit', 'Monthly', 25, 4.2, 'Stable', 'Good', 'Good'),
(22, 20, 'CardioCore', 'peshawar', '987-654-3210', 'sana@example.com', 'Gym, Cardio', 'Monthly', 20, 4.2, 'Declining', 'Good', 'Good'),
(23, 21, 'AerobicsArena', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Aerobics', 'Monthly, Yearly', 45, 4.5, 'Growing', 'Good', 'Good'),
(24, 22, 'WeightliftingWorld', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Weightlifting', 'Monthly', 30, 4.0, 'Stable', 'Good', 'Good'),
(25, 23, 'YogaZone', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Yoga', 'Yearly', 40, 4.3, 'Growing', 'Good', 'Good'),
(26, 24, 'PilatesPalace', 'pindi', '987-654-3210', 'sana@example.com', 'Gym, Pilates', 'Monthly', 25, 4.2, 'Stable', 'Good', 'Good'),
(27, 25, 'ZumbaZen', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Zumba', 'Monthly', 35, 4.4, 'Declining', 'Good', 'Good'),
(28, 26, 'SpinStudio', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Spinning', 'Monthly', 40, 4.3, 'Growing', 'Good', 'Good'),
(29, 27, 'BootcampBlast', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Bootcamp', 'Monthly, Yearly', 30, 4.1, 'Stable', 'Good', 'Good'),
(30, 28, 'MartialArtsMadness', 'peshawar', '987-654-3210', 'sana@example.com', 'Gym, Martial Arts', 'Monthly', 20, 4.2, 'Declining', 'Good', 'Good'),
(31, 29, 'CrossFitCentral', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, CrossFit', 'Monthly', 45, 4.5, 'Growing', 'Good', 'Good'),
(32, 30, 'CardioCraze', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Cardio', 'Monthly, Quarterly', 30, 4.0, 'Stable', 'Good', 'Good'),
(33, 31, 'AerobicsAthletic', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Aerobics', 'Yearly', 40, 4.3, 'Growing', 'Good', 'Good'),
(34, 32, 'WeightliftingWarehouse', 'pindi', '987-654-3210', 'sana@example.com', 'Gym, Weightlifting', 'Monthly', 25, 4.2, 'Stable', 'Good', 'Good'),
(35, 33, 'YogaLAWN', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Yoga', 'Monthly', 35, 4.4, 'Declining', 'Good', 'Good'),
(36, 34, 'PilatesPlaceDamn', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Pilates', 'Monthly, Yearly', 30, 4.0, 'Growing', 'Good', 'Good'),
(37, 35, 'ZumbaZonewextreme', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Zumba', 'Monthly', 40, 4.3, 'Stable', 'Good', 'Good'),
(38, 36, 'SpinyCity', 'peshawar', '987-654-3210', 'sana@example.com', 'Gym, Spinning', 'Monthly', 20, 4.2, 'Declining', 'Good', 'Good'),
(39, 37, 'BootBase', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Bootcamp', 'Monthly', 45, 4.5, 'Growing', 'Good', 'Good'),
(40, 38, 'HVYgym', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Martial Arts', 'Monthly, Quarterly', 30, 4.0, 'Stable', 'Good', 'Good'),
(41, 39, 'CrossFitDomination', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, CrossFit', 'Yearly', 40, 4.3, 'Declining', 'Good', 'Good'),
(42, 40, 'Cardiaccanal', 'peshawar', '987-654-3210', 'sana@example.com', 'Gym, Cardio', 'Monthly', 25, 4.2, 'Growing', 'Good', 'Good'),
(43, 41, 'AerobicsArena', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Aerobics', 'Monthly', 35, 4.4, 'Stable', 'Good', 'Good'),
(44, 42, 'WeightliftingGlobe', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Weightlifting', 'Monthly, Yearly', 30, 4.0, 'Declining', 'Good', 'Good'),
(45, 43, 'YogaALpha', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Yoga', 'Monthly', 40, 4.3, 'Growing', 'Good', 'Good'),
(46, 44, 'PilatesPalace', 'pindi', '987-654-3210', 'sana@example.com', 'Gym, Pilates', 'Yearly', 25, 4.2, 'Stable', 'Good', 'Good'),
(47, 45, 'ZumbaZen', 'islamabad', '123-456-7890', 'ali@example.com', 'Gym, Zumba', 'Monthly', 35, 4.4, 'Growing', 'Good', 'Good'),
(48, 46, 'WOWStudio', 'lahore', '987-654-3210', 'sana@example.com', 'Gym, Spinning', 'Monthly, Yearly', 40, 4.0, 'Stable', 'Good', 'Good'),
(49, 47, 'BellBlast', 'karachi', '123-456-7890', 'ali@example.com', 'Gym, Bootcamp', 'Monthly', 25, 4.3, 'Declining', 'Good', 'Good'),
(50, 48, 'KhabibGYM', 'peshawar', '987-654-3210', 'sana@example.com', 'Gym, Martial Arts', 'Monthly', 20, 4.2, 'Growing', 'Good', 'Good');


CREATE TABLE RequestedGyms (
    RequestID INT PRIMARY KEY IDENTITY,
    GymID INT,
    OwnerID INT,
	
    FOREIGN KEY (GymID) REFERENCES Gym(GymID),
);
INSERT INTO RequestedGyms (GymID, OwnerID) VALUES
(1, 10),
(2, 5),
(3, 12),
(4, 7),
(5, 15),
(15, 18),
(26, 23),
(38, 9),
(19, 8),
(28, 3),
(10, 14),
(22, 2),
(33, 1),
(6, 20),
(47, 17),
(11, 16),
(20, 13),
(31, 6),
(9, 19),
(41, 11),
(4, 25),
(18, 22),
(27, 21),
(35, 4),
(7, 24),
(12, 26),
(48, 27),
(21, 28),
(37, 29),
(3, 30),
(23, 31),
(34, 32),
(50, 33),
(13, 34),
(30, 35),
(40, 36),
(45, 37),
(36, 38),
(14, 39),
(16, 40),
(44, 41),
(39, 42),
(25, 43),
(8, 44),
(24, 45),
(43, 46),
(29, 47),
(42, 48),
(17, 49),
(32, 50);



CREATE TABLE ApprovedGyms (
    RequestID INT PRIMARY KEY IDENTITY,
    GymID INT,
    Status VARCHAR(255),
    FOREIGN KEY (GymID) REFERENCES Gym(GymID)
);
INSERT INTO ApprovedGyms (GymID, Status)
VALUES
(1, 'Approved'),
(2, 'Approved'),
(3, 'Approved'),
(4, 'Approved'),
(5, 'Approved'),
(6, 'Approved'),
(7, 'Approved'),
(8, 'Approved'),
(9, 'Approved'),
(10, 'Approved');


---------------------------------------------------------------------------Owner



CREATE TABLE Owner (
    OwnerID INT PRIMARY KEY IDENTITY,
    GymID INT,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(100),
    ContactNumber VARCHAR(20)
	FOREIGN KEY (GymID) REFERENCES Gym(GymID)

);

INSERT INTO Owner (GymID, Name, Email, Username, Password, ContactNumber)
VALUES
(1, 'Ali Khan', 'ali@example.com', 'owner01', '1234', '0300-1234567'),
(2, 'Sana Ahmed', 'sana@example.com', 'owner02', '1234', '0312-9876543'),
(3, 'Ahmed Hassan', 'ahmed@example.com', 'owner03', '1234', '0321-5678901'),
(4, 'Fatima Ali', 'fatima@example.com', 'owner04', '1234', '0333-1122334'),
(5, 'Hassan Raza', 'hassan@example.com', 'owner05', '1234', '0344-5566778'),
(6, 'Aisha Malik', 'aisha@example.com', 'owner06', '1234', '0355-9988776'),
(7, 'Zainab Khan', 'zainab@example.com', 'owner07', '1234', '0311-2233445'),
(8, 'Usman Butt', 'usman@example.com', 'owner08', '1234', '0302-3344556'),
(9, 'Nida Khan', 'nida@example.com', 'owner09', '1234', '0322-6677889'),
(10, 'Tariq Mehmood', 'tariq@example.com', 'owner10', '1234', '0331-4455667'),
(11, 'Saima Javed', 'saima@example.com', 'owner11', '1234', '0313-7788990'),
(12, 'Bilal Ahmed', 'bilal@example.com', 'owner12', '1234', '0323-1122334'),
(13, 'Sara Aslam', 'sara@example.com', 'owner13', '1234', '0343-5566778'),
(14, 'Khalid Raza', 'khalid@example.com', 'owner14', '1234', '0354-9988776'),
(15, 'Ayesha Aziz', 'ayesha@example.com', 'owner15', '1234', '0312-2233445'),
(16, 'Farhan Ali', 'farhan@example.com', 'owner16', '1234', '0301-3344556'),
(17, 'Nadia Khan', 'nadia@example.com', 'owner17', '1234', '0320-6677889'),
(18, 'Ahmed Tariq', 'ahmedtariq@example.com', 'owner18', '1234', '0330-4455667'),
(19, 'Saba Saima', 'sabasaima@example.com', 'owner19', '1234', '0311-7788990'),
(20, 'Asad Bilal', 'asadbilal@example.com', 'owner20', '1234', '0324-1122334'),
(21, 'Ali', 'ali@example.com', 'ali01', '1234', '0300-1234567'),
(22, 'Sana', 'sana@example.com', 'sana02', '1234', '0312-9876543'),
(23, 'Ahmed', 'ahmed@example.com', 'ahmed03', '1234', '0321-5678901'),
(24, 'Fatima', 'fatima@example.com', 'fatima04', '1234', '0333-1122334'),
(25, 'Hassan', 'hassan@example.com', 'hassan05', '1234', '0344-5566778'),
(26, 'Aisha', 'aisha@example.com', 'aisha06', '1234', '0355-9988776'),
(27, 'Zainab', 'zainab@example.com', 'zainab07', '1234', '0311-2233445'),
(28, 'Usman', 'usman@example.com', 'usman08', '1234', '0302-3344556'),
(29, 'Nida', 'nida@example.com', 'nida09', '1234', '0322-6677889'),
(30, 'Tariq', 'tariq@example.com', 'tariq10', '1234', '0331-4455667'),
(31, 'Saima', 'saima@example.com', 'saima11', '1234', '0313-7788990'),
(32, 'Bilal', 'bilal@example.com', 'bilal12', '1234', '0323-1122334'),
(33, 'Sara', 'sara@example.com', 'sara13', '1234', '0343-5566778'),
(34, 'Khalid', 'khalid@example.com', 'khalid14', '1234', '0354-9988776'),
(35, 'Ayesha', 'ayesha@example.com', 'ayesha15', '1234', '0312-2233445'),
(36, 'Farhan', 'farhan@example.com', 'farhan16', '1234', '0301-3344556'),
(37, 'Nadia', 'nadia@example.com', 'nadia17', '1234', '0320-6677889'),
(38, 'Ahmed T.', 'ahmedt@example.com', 'ahmedt18', '1234', '0330-4455667'),
(39, 'Saba', 'saba@example.com', 'saba19', '1234', '0311-7788990'),
(40, 'Asad', 'asad@example.com', 'asad20', '1234', '0324-1122334'),
(41, 'Zara', 'zara@example.com', 'zara21', '1234', '0300-1234567'),
(42, 'Aliya', 'aliya@example.com', 'aliya22', '1234', '0312-9876543'),
(43, 'Ahmed A.', 'ahmeda@example.com', 'ahmeda23', '1234', '0321-5678901'),
(44, 'Fiza', 'fiza@example.com', 'fiza24', '1234', '0333-1122334'),
(45, 'Hamza', 'hamza@example.com', 'hamza25', '1234', '0344-5566778'),
(46, 'Amina', 'amina@example.com', 'amina26', '1234', '0355-9988776'),
(47, 'Zaid', 'zaid@example.com', 'zaid27', '1234', '0311-2233445'),
(48, 'Umar', 'umar@example.com', 'umar28', '1234', '0302-3344556'),
(49, 'Nazia', 'nazia@example.com', 'nazia29', '1234', '0322-6677889'),
(50, 'Taha', 'taha@example.com', 'taha30', '1234', '0331-4455667');




select * from gym 


---------------------------------------------------------------------------TRAINER


CREATE TABLE Trainer (
    TrainerID INT PRIMARY KEY IDENTITY,
    Name VARCHAR(255),
    Username VARCHAR(255) UNIQUE,
    Password VARCHAR(255),
    Email VARCHAR(255),
    DOB varchar(255),
    Address VARCHAR(255),
    ExperienceYears INT,
    AverageRating FLOAT,
    CertificationLevel VARCHAR(50),
    ContactNo VARCHAR(20),

	GymID int,
	FOREIGN KEY (GymID) REFERENCES Gym(GymID)

);
INSERT INTO Trainer (Name, Username, Password, Email, DOB, Address, ExperienceYears, AverageRating, CertificationLevel, ContactNo, GymID)
VALUES
('Brad Pitt', 'trainer01', '1234', 'bp@example.com', '1963-12-18', '123 Main St, Los Angeles, USA', 5, 4.7, 'Advanced', '1234567890', 1),
('Angelina Jolie', 'trainer02', '1234', 'aj@example.com', '1975-06-04', '456 Oak Ave, Los Angeles, USA', 3, 4.3, 'Intermediate', '9876543210', 2),
('Tom Cruise', 'trainer03', '1234', 'tc@example.com', '1962-07-03', '789 Elm Rd, Los Angeles, USA', 7, 4.9, 'Expert', '3456789012', 3),
('Jennifer Aniston', 'trainer04', '1234', 'ja@example.com', '1969-02-11', '101 Pine Blvd, Los Angeles, USA', 4, 4.5, 'Advanced', '8901234567', 4),
('Leonardo DiCaprio', 'trainer05', '1234', 'ld@example.com', '1974-11-11', '202 Maple Ln, Los Angeles, USA', 6, 4.6, 'Expert', '4567890123', 5),
('Scarlett Johansson', 'trainer06', '1234', 'sj@example.com', '1984-11-22', '303 Cedar St, Los Angeles, USA', 2, 4.1, 'Intermediate', '2345678901', 6),
('Dwayne Johnson', 'trainer07', '1234', 'dj@example.com', '1972-05-02', '404 Pine Rd, Los Angeles, USA', 8, 4.8, 'Expert', '7890123456', 7),
('Emma Watson', 'trainer08', '1234', 'ew@example.com', '1990-04-15', '505 Cedar Ave, Los Angeles, USA', 5, 4.7, 'Advanced', '3456789012', 8),
('Robert Downey Jr.', 'trainer09', '1234', 'rdj@example.com', '1965-04-04', '606 Oak St, Los Angeles, USA', 7, 4.9, 'Expert', '6789012345', 9),
('Chris Hemsworth', 'trainer10', '1234', 'ch@example.com', '1983-08-11', '707 Elm Dr, Los Angeles, USA', 6, 4.6, 'Expert', '9012345678', 10),
('Gal Gadot', 'trainer11', '1234', 'gg@example.com', '1985-04-30', '808 Pine Ave, Los Angeles, USA', 4, 4.5, 'Advanced', '1234509876', 12),
('Tom Hanks', 'trainer12', '1234', 'th@example.com', '1956-07-09', '909 Maple Blvd, Los Angeles, USA', 8, 4.8, 'Expert', '9876543210', 11),
('Jennifer Lawrence', 'trainer13', '1234', 'jl@example.com', '1990-08-15', '1010 Cedar Rd, Los Angeles, USA', 6, 4.6, 'Expert', '8765432109', 26),
('Will Smith', 'trainer14', '1234', 'ws@example.com', '1968-09-25', '1111 Oak Ln, Los Angeles, USA', 7, 4.9, 'Expert', '7654321098', 13),
('Meryl Streep', 'trainer15', '1234', 'ms@example.com', '1949-06-22', '1212 Elm Ct, Los Angeles, USA', 5, 4.7, 'Advanced', '6543210987', 14),
('Johnny Depp', 'trainer16', '1234', 'jd@example.com', '1963-06-09', '1313 Pine Rd, Los Angeles, USA', 9, 5.0, 'Expert', '5432109876', 15),
('Charlize Theron', 'trainer17', '1234', 'ct@example.com', '1975-08-07', '1414 Maple Ave, Los Angeles, USA', 4, 4.5, 'Advanced', '4321098765', 16),
('Bradley Cooper', 'trainer18', '1234', 'bc@example.com', '1975-01-05', '1515 Cedar St, Los Angeles, USA', 6, 4.6, 'Expert', '3210987654', 17),
('Halle Berry', 'trainer19', '1234', 'hb@example.com', '1966-08-14', '1616 Oak Dr, Los Angeles, USA', 7, 4.9, 'Expert', '2109876543', 18),
('Matt Damon', 'trainer20', '1234', 'md@example.com', '1970-10-08', '1717 Elm Ave, Los Angeles, USA', 5, 4.7, 'Advanced', '1098765432', 19),
('Jennifer Lopez', 'trainer21', '1234', 'jlo@example.com', '1969-07-24', '1818 Pine Blvd, Los Angeles, USA', 6, 4.6, 'Expert', '0987654321', 20),
('Ryan Reynolds', 'trainer22', '1234', 'rr@example.com', '1976-10-23', '1919 Oak Ave, Los Angeles, USA', 8, 4.8, 'Expert', '9876543210', 21),
('Julia Roberts', 'trainer23', '1234', 'jr@example.com', '1967-10-28', '2020 Elm Rd, Los Angeles, USA', 7, 4.9, 'Expert', '8765432109', 22),
('Chris Evans', 'trainer24', '1234', 'ce@example.com', '1981-06-13', '2121 Maple Ln, Los Angeles, USA', 6, 4.6, 'Expert', '7654321098', 23),
('Natalie Portman', 'trainer25', '1234', 'np@example.com', '1981-06-09', '2222 Cedar St, Los Angeles, USA', 5, 4.7, 'Advanced', '6543210987', 24),
('Vin Diesel', 'trainer26', '1234', 'vd@example.com', '1967-07-18', '2323 Oak Dr, Los Angeles, USA', 9, 5.0, 'Expert', '5432109876', 25);
INSERT INTO Trainer (Name, Username, Password, Email, DOB, Address, ExperienceYears, AverageRating, CertificationLevel, ContactNo, GymID)
VALUES
('Shraddha Kapoor', 'trainer27', '1234', 'shraddha@example.com', '1987-03-03', '356 Kapoor Lane, Mumbai, India', 6, 4.7, 'Advanced', '7788990011', 26),
('Aishwarya Rai', 'trainer28', '1234', 'aishwarya@example.com', '1973-11-01', '378 Rai Mansion, Mumbai, India', 7, 4.8, 'Advanced', '8899001122', 27),
('Ranbir Kapoor', 'trainer29', '1234', 'ranbir@example.com', '1982-09-28', '400 Kapoor House, Mumbai, India', 8, 4.9, 'Expert', '9900112233', 28),
('Kangana Ranaut', 'trainer30', '1234', 'kangana@example.com', '1986-03-23', '423 Ranaut Road, Mumbai, India', 6, 4.7, 'Advanced', '0011223344', 29),
('Shah Rukh Khan', 'trainer31', '1234', 'srk@example.com', '1965-11-02', '12 Bollywood Blvd, Mumbai, India', 9, 4.9, 'Expert', '1122334455', 30),
('Deepika Padukone', 'trainer32', '1234', 'deepika@example.com', '1986-01-05', '34 Film City, Mumbai, India', 7, 4.8, 'Expert', '2233445566', 31),
('Salman Khan', 'trainer33', '1234', 'salman@example.com', '1965-12-27', '56 Galaxy Apartments, Mumbai, India', 8, 4.7, 'Advanced', '3344556677', 32),
('Priyanka Chopra', 'trainer34', '1234', 'priyanka@example.com', '1982-07-18', '78 Juhu Beach, Mumbai, India', 6, 4.6, 'Expert', '4455667788', 33),
('Aamir Khan', 'trainer35', '1234', 'aamir@example.com', '1965-03-14', '90 Bandra West, Mumbai, India', 9, 4.9, 'Expert', '5566778899', 34),
('Kareena Kapoor', 'trainer36', '1234', 'kareena@example.com', '1980-09-21', '112 Pataudi Palace, Haryana, India', 8, 4.8, 'Advanced', '6677889900', 35),
('Hrithik Roshan', 'trainer37', '1234', 'hrithik@example.com', '1974-01-10', '134 Green Acres, Mumbai, India', 7, 4.7, 'Expert', '7788990011', 36),
('Alia Bhatt', 'trainer38', '1234', 'alia@example.com', '1993-03-15', '156 Bhatt House, Mumbai, India', 5, 4.5, 'Intermediate', '8899001122', 37),
('Ranveer Singh', 'trainer39', '1234', 'ranveer@example.com', '1985-07-06', '178 Singh Mansion, Mumbai, India', 6, 4.6, 'Expert', '9900112233', 38),
('Katrina Kaif', 'trainer40', '1234', 'katrina@example.com', '1983-07-16', '200 Kaif Villa, Mumbai, India', 7, 4.8, 'Advanced', '0011223344', 39),
('Shahid Kapoor', 'trainer41', '1234', 'shahid@example.com', '1981-02-25', '223 Kapoor Lane, Mumbai, India', 8, 4.9, 'Expert', '1122334455', 40),
('Anushka Sharma', 'trainer42', '1234', 'anushka@example.com', '1988-05-01', '256 Sharma Street, Mumbai, India', 6, 4.7, 'Advanced', '2233445566', 41),
('Varun Dhawan', 'trainer43', '1234', 'varun@example.com', '1987-04-24', '278 Dhawan Road, Mumbai, India', 5, 4.6, 'Intermediate', '3344556677', 42),
('Akshay Kumar', 'trainer44', '1234', 'akshay@example.com', '1967-09-09', '300 Kumar Complex, Mumbai, India', 9, 4.9, 'Expert', '4455667788', 43),
('Sonam Kapoor', 'trainer45', '1234', 'sonam@example.com', '1985-06-09', '312 Kapoor Tower, Mumbai, India', 7, 4.8, 'Advanced', '5566778899', 44),
('Ajay Devgn', 'trainer46', '1234', 'ajay@example.com', '1969-04-02', '334 Devgn Estate, Mumbai, India', 8, 4.9, 'Expert', '6677889900', 45),
('Shraddha Kapoor', 'trainer47', '1234', 'shraddha@example.com', '1987-03-03', '356 Kapoor Lane, Mumbai, India', 6, 4.7, 'Advanced', '7788990011', 46),
('Aishwarya Rai', 'trainer48', '1234', 'aishwarya@example.com', '1973-11-01', '378 Rai Mansion, Mumbai, India', 7, 4.8, 'Advanced', '8899001122', 47),
('Ranbir Kapoor', 'trainer49', '1234', 'ranbir@example.com', '1982-09-28', '400 Kapoor House, Mumbai, India', 8, 4.9, 'Expert', '9900112233', 48),
('Kangana Ranaut', 'trainer50', '1234', 'kangana@example.com', '1986-03-23', '423 Ranaut Road, Mumbai, India', 6, 4.7, 'Advanced', '0011223344', 49);
select * from trainer 



---------------------------------------------------------------------------member



CREATE TABLE Member (
    MemberID INT PRIMARY KEY IDENTITY,
    Name VARCHAR(255),
    Username VARCHAR(255) UNIQUE,
    Password VARCHAR(255),
    Email VARCHAR(255),
    DOB Varchar(255),
    Address VARCHAR(255),
    Contact VARCHAR(10),
    EmergencyContact VARCHAR(10),
    Weight DECIMAL(5, 2),
    Height DECIMAL(5, 2),
    MembershipDuration VARCHAR(50),
	JoiningDate DATE,
    FitnessGoals VARCHAR(255),
    TrainerID INT,
    FOREIGN KEY (TrainerID) REFERENCES Trainer(TrainerID),
    GymID INT,

    FOREIGN KEY (GymID) REFERENCES Gym(GymID)
);

INSERT INTO Member (Name, Username, Password, Email, DOB, JoiningDate, Address, Contact, EmergencyContact, Weight, Height, MembershipDuration, FitnessGoals, GymID)
VALUES 
('Shahrukh Khan', 'member01', '1234', 'shahrukh.khan@example.com', '1965-11-02', '2022-01-01', '123 Mannat, Mumbai, India', '1234567890', '9876543210', 70.5, 175.3, '1 year', 'Lose weight', 1),
('Deepika Padukone', 'member02', '1234', 'deepika.padukone@example.com', '1986-01-05', '2022-01-02', '456 Prabha Devi, Mumbai, India', '2345678901', '8901234567', 60.2, 165.0, '6 months', 'Build muscle', 2),
('Salman Khan', 'member03', '1234', 'salman.khan@example.com', '1965-12-27', '2022-01-03', '789 Galaxy Apartments, Mumbai, India', '3456789012', '9012345678', 55.0, 160.5, '3 months', 'Improve endurance', 3),
('Priyanka Chopra', 'member04', '1234', 'priyanka.chopra@example.com', '1982-07-18', '2022-01-04', '101 Versova, Mumbai, India', '4567890123', '0123456789', 80.0, 180.0, '1 year', 'Increase strength', 1),
('Amitabh Bachchan', 'member05', '1234', 'amitabh.bachchan@example.com', '1942-10-11', '2022-01-05', '202 Juhu, Mumbai, India', '5678901234', '1234567890', 65.7, 170.2, '6 months', 'Stay fit', 2),
('Mahira Khan', 'member06', '1234', 'mahira.khan@example.com', '1984-12-21', '2022-01-06', '123 Zamzama, Karachi, Pakistan', '6789012345', '2345678901', 68.3, 168.5, '1 year', 'Lose weight', 3),
('Fawad Khan', 'member07', '1234', 'fawad.khan@example.com', '1981-11-29', '2022-01-07', '456 Defence, Karachi, Pakistan', '7890123456', '3456789012', 75.1, 175.0, '9 months', 'Build muscle', 4),
('Saba Qamar', 'member08', '1234', 'saba.qamar@example.com', '1984-04-05', '2022-01-08', '789 Gulberg, Lahore, Pakistan', '8901234567', '4567890123', 62.0, 163.0, '6 months', 'Improve endurance', 5),
('Atif Aslam', 'member09', '1234', 'atif.aslam@example.com', '1983-03-12', '2022-01-09', '101 DHA, Lahore, Pakistan', '9012345678', '5678901234', 78.5, 180.5, '1 year', 'Increase strength', 6),
('Mawra Hocane', 'member10', '1234', 'mawra.hocane@example.com', '1992-09-28', '2022-01-10', '202 Clifton, Karachi, Pakistan', '0123456789', '6789012345', 55.8, 167.8, '9 months', 'Stay fit', 7),
('Ranbir Kapoor', 'member11', '1234', 'ranbir.kapoor@example.com', '1982-09-28', '2022-01-11', '101 Krishna Raj, Mumbai, India', '1234509876', '7890123456', 72.4, 178.0, '1 year', 'Lose weight', 1),
('Kareena Kapoor', 'member12', '1234', 'kareena.kapoor@example.com', '1980-09-21', '2022-01-12', '404 Fortune Heights, Mumbai, India', '2345678901', '8901234567', 61.5, 166.0, '6 months', 'Build muscle', 2),
('Aishwarya Rai', 'member13', '1234', 'aishwarya.rai@example.com', '1973-11-01', '2022-01-13', '707 Prateeksha, Mumbai, India', '3456789012', '9012345678', 57.2, 163.0, '3 months', 'Improve endurance', 3),
('Hrithik Roshan', 'member14', '1234', 'hrithik.roshan@example.com', '1974-01-10', '2022-01-14', '808 El Palazzo, Mumbai, India', '4567890123', '0123456789', 82.3, 182.0, '1 year', 'Increase strength', 1),
('Katrina Kaif', 'member15', '1234', 'katrina.kaif@example.com', '1983-07-16', '2022-01-15', '909 Galaxy Apartments, Mumbai, India', '5678901234', '1234567890', 66.8, 171.0, '6 months', 'Stay fit', 2),
('Sajal Aly', 'member16', '1234', 'sajal.aly@example.com', '1994-01-17', '2022-01-16', '123 Defence, Karachi, Pakistan', '6789012345', '2345678901', 70.1, 170.5, '1 year', 'Lose weight', 3),
('Bilal Abbas Khan', 'member17', '1234', 'bilal.khan@example.com', '1993-06-04', '2022-01-17', '456 Gulberg, Lahore, Pakistan', '7890123456', '3456789012', 72.6, 175.0, '9 months', 'Build muscle', 4),
('Mehwish Hayat', 'member18', '1234', 'mehwish.hayat@example.com', '1983-01-06', '2022-01-18', '789 Clifton, Karachi, Pakistan', '8901234567', '4567890123', 59.3, 165.0, '6 months', 'Improve endurance',2),
('Imran Abbas', 'member19', '1234', 'imran.abbas@example.com', '1982-10-15', '2022-01-19', '101 Defence, Karachi, Pakistan', '9012345678', '5678901234', 77.0, 180.0, '1 year', 'Increase strength', 3),
('Saba Qamar', 'member20', '1234', 'saba.qamar@example.com', '1984-04-05', '2022-01-20', '202 Gulberg, Lahore, Pakistan', '0123456789', '6789012345', 62.0, 163.0, '9 months', 'Stay fit', 5),
('Adnan Malik', 'member21', '1234', 'adnan.malik@example.com', '1984-06-24', '2022-01-21', '303 DHA, Lahore, Pakistan', '1234509876', '7890123456', 75.8, 175.5, '1 year', 'Lose weight', 6),
('Aiman Khan', 'member22', '1234', 'aiman.khan@example.com', '1998-11-20', '2022-01-22', '404 Clifton, Karachi, Pakistan', '2345678901', '8901234567', 55.5, 165.0, '6 months', 'Build muscle', 7),
('Humayun Saeed', 'member23', '1234', 'humayun.saeed@example.com', '1971-07-27', '2022-01-23', '505 Defence, Karachi, Pakistan', '3456789012', '9012345678', 80.2, 178.0, '3 months', 'Improve endurance', 8),
('Sajal Aly', 'member24', '1234', 'sajal.aly@example.com', '1994-01-17', '2022-01-24', '606 Gulberg, Lahore, Pakistan', '4567890123', '0123456789', 68.7, 170.0, '1 year', 'Increase strength', 9),
('Ahad Raza Mir', 'member25', '1234', 'ahad.mir@example.com', '1993-09-29', '2022-01-25', '707 Model Town, Lahore, Pakistan', '5678901234', '1234567890', 63.4, 173.0, '9 months', 'Stay fit', 10),
('Iqra Aziz', 'member26', '1234', 'iqra.aziz@example.com', '1997-11-24', '2022-01-26', '808 DHA, Karachi, Pakistan', '6789012345', '2345678901', 57.9, 163.0, '6 months', 'Lose weight', 11),
('Feroze Khan', 'member27', '1234', 'feroze.khan@example.com', '1990-07-11', '2022-01-27', '909 Clifton, Karachi, Pakistan', '7890123456', '3456789012', 71.0, 177.0, '3 months', 'Build muscle', 12),
('Maya Ali', 'member28', '1234', 'maya.ali@example.com', '1989-07-27', '2022-01-28', '101 Gulberg, Lahore, Pakistan', '8901234567', '4567890123', 65.3, 168.0, '1 year', 'Improve endurance', 13),
('Ali Zafar', 'member29', '1234', 'ali.zafar@example.com', '1980-05-18', '2022-01-29', '202 DHA, Lahore, Pakistan', '9012345678', '5678901234', 75.6, 180.0, '9 months', 'Increase strength', 14),
('Saba Qamar', 'member30', '1234', 'saba.qamar@example.com', '1984-04-05', '2022-01-30', '303 Clifton, Karachi, Pakistan', '0123456789', '6789012345', 60.1, 165.0, '6 months', 'Stay fit', 15),
('Hamza Ali Abbasi', 'member31', '1234', 'hamza.abbasi@example.com', '1984-06-23', '2022-01-31', '404 Defence, Karachi, Pakistan', '1234509876', '7890123456', 77.3, 179.0, '3 months', 'Lose weight', 16),
('Ayeza Khan', 'member32', '1234', 'ayeza.khan@example.com', '1991-01-15', '2022-02-01', '505 Gulberg, Lahore, Pakistan', '2345678901', '8901234567', 62.8, 166.0, '1 year', 'Build muscle', 17),
('Ahmed Ali Butt', 'member33', '1234', 'ahmed.butt@example.com', '1976-01-26', '2022-02-02', '606 Model Town, Lahore, Pakistan', '3456789012', '9012345678', 85.2, 183.0, '1 year', 'Improve endurance', 18),
('Sohai Ali Abro', 'member34', '1234', 'sohai.abro@example.com', '1994-05-13', '2022-02-03', '707 Clifton, Karachi, Pakistan', '4567890123', '0123456789', 58.5, 166.0, '6 months', 'Increase strength', 19),
('Danish Taimoor', 'member35', '1234', 'danish.taimoor@example.com', '1983-02-16', '2022-02-04', '808 Gulberg, Lahore, Pakistan', '5678901234', '1234567890', 73.9, 177.0, '3 months', 'Stay fit', 20),
('Saba Qamar', 'member36', '1234', 'saba.qamar@example.com', '1984-04-05', '2022-02-05', '909 DHA, Karachi, Pakistan', '6789012345', '2345678901', 65.4, 169.0, '1 year', 'Lose weight', 21),
('Ali Zafar', 'member37', '1234', 'ali.zafar@example.com', '1980-05-18', '2022-02-06', '101 Defence, Karachi, Pakistan', '7890123456', '3456789012', 77.6, 179.0, '9 months', 'Build muscle', 22),
('Mehwish Hayat', 'member38', '1234', 'mehwish.hayat@example.com', '1983-01-06', '2022-02-07', '202 Gulberg, Lahore, Pakistan', '8901234567', '4567890123', 61.3, 165.0, '6 months', 'Improve endurance', 23),
('Ahsan Khan', 'member39', '1234', 'ahsan.khan@example.com', '1981-10-09', '2022-02-08', '303 Clifton, Karachi, Pakistan', '9012345678', '5678901234', 76.2, 178.0, '1 year', 'Increase strength', 24),
('Ayeza Khan', 'member40', '1234', 'ayeza.khan@example.com', '1991-01-15', '2022-02-09', '404 Gulberg, Lahore, Pakistan', '0123456789', '6789012345', 63.8, 167.0, '9 months', 'Stay fit', 25),
('Adnan Malik', 'member41', '1234', 'adnan.malik@example.com', '1984-06-24', '2022-02-10', '505 DHA, Lahore, Pakistan', '1234509876', '7890123456', 74.5, 176.0, '6 months', 'Lose weight', 26),
('Sajal Aly', 'member42', '1234', 'sajal.aly@example.com', '1994-01-17', '2022-02-11', '606 Defence, Karachi, Pakistan', '2345678901', '8901234567', 69.7, 171.0, '3 months', 'Build muscle', 27),
('Humayun Saeed', 'member43', '1234', 'humayun.saeed@example.com', '1971-07-27', '2022-02-12', '707 Clifton, Karachi, Pakistan', '3456789012', '9012345678', 81.8, 180.0, '1 year', 'Improve endurance', 28),
('Maya Ali', 'member44', '1234', 'maya.ali@example.com', '1989-07-27', '2022-02-13', '808 Gulberg, Lahore, Pakistan', '4567890123', '0123456789', 66.2, 169.0, '9 months', 'Increase strength', 29),
('Feroze Khan', 'member45', '1234', 'feroze.khan@example.com', '1990-07-11', '2022-02-14', '909 DHA, Lahore, Pakistan', '5678901234', '1234567890', 72.1, 175.0, '6 months', 'Stay fit', 30),
('Aiman Khan', 'member46', '1234', 'aiman.khan@example.com', '1998-11-20', '2022-02-15', '101 Model Town, Lahore, Pakistan', '6789012345', '2345678901', 56.4, 164.0, '3 months', 'Lose weight', 31),
('Ahad Raza Mir', 'member47', '1234', 'ahad.mir@example.com', '1993-09-29', '2022-02-16', '202 Clifton, Karachi, Pakistan', '7890123456', '3456789012', 64.5, 171.0, '1 year', 'Build muscle', 32),
('Iqra Aziz', 'member48', '1234', 'iqra.aziz@example.com', '1997-11-24', '2022-02-17', '303 Defence, Karachi, Pakistan', '8901234567', '4567890123', 58.9, 165.0, '9 months', 'Improve endurance', 33),
('Ali Zafar', 'member49', '1234', 'ali.zafar@example.com', '1980-05-18', '2022-02-18', '404 Gulberg, Lahore, Pakistan', '9012345678', '5678901234', 78.3, 179.0, '6 months', 'Increase strength', 34),
('Saba Qamar', 'member50', '1234', 'saba.qamar@example.com', '1984-04-05', '2022-02-19', '505 DHA, Lahore, Pakistan', '0123456789', '6789012345', 63.7, 167.0, '3 months', 'Stay fit', 35);


---------------------------------------------------------------------------Workout


CREATE TABLE WorkoutPlan (
    PlanID INT PRIMARY KEY IDENTITY,
    Name VARCHAR(255) Unique,
    CreatorTrainerID INT,
    CreatorMemberID INT,
    TrainerRemarks VARCHAR(255),
    Difficulty VARCHAR(50),
	WorkoutDuration VARCHAR(50),
    FOREIGN KEY (CreatorTrainerID) REFERENCES Trainer(TrainerID),
    FOREIGN KEY (CreatorMemberID) REFERENCES Member(MemberID)
);
INSERT INTO WorkoutPlan (Name, CreatorTrainerID, CreatorMemberID, TrainerRemarks, Difficulty)
VALUES 
('Full Body Workout', 1, NULL, 'Focus on strength and endurance', 'High'),
('Cardio Blast', NULL, 3, 'High-intensity cardio session', 'Low'),
('Upper Body Strength', 2, NULL, 'Targeting arms, chest, and back', 'High'),
('Leg Day', 1, NULL, 'Intense leg workout', 'Medium'),
('Core Strength', NULL, 4, 'Core muscle focus', 'Low'),
('HIIT Circuit', 3, NULL, 'High-intensity interval training', 'High'),
('Weight Loss Program', NULL, 5, 'Focus on burning calories', 'Low'),
('Muscle Building', 2, NULL, 'Designed for muscle gain', 'Medium'),
('Flexibility and Mobility', 4, NULL, 'Improving flexibility and mobility', 'High'),
('Endurance Training', NULL, 1, 'Long-duration training', 'Low'),
('Strength Training', 1, NULL, 'Focus on building strength', 'High'),
('Yoga and Meditation', NULL, 3, 'Stress relief and flexibility', 'Low'),
('Pilates', 2, NULL, 'Core strength and flexibility', 'Medium'),
('CrossFit', NULL, 4, 'High-intensity functional movements', 'High'),
('Zumba Fitness', 3, NULL, 'Dance-based cardio workout', 'Low'),
('Kickboxing Workout', NULL, 5, 'Combination of cardio and martial arts', 'Medium'),
('Circuit Training', 4, NULL, 'Rotating through different exercises', 'High'),
('Tabata Training', NULL, 1, 'High-intensity interval training', 'Low'),
('TRX Suspension Training', 1, NULL, 'Using body weight and TRX straps', 'Medium'),
('Bootcamp Workout', NULL, 3, 'Military-style fitness training', 'High'),
('Strength and Conditioning', 3, NULL, 'Focus on overall strength and conditioning', 'Medium'),
('Yoga Flow', NULL, 4, 'Dynamic yoga sequence for flexibility and relaxation', 'Low'),
('HIIT and Core', 2, NULL, 'Combination of high-intensity intervals and core exercises', 'High'),
('Bodyweight Blast', NULL, 5, 'Full-body workout using only bodyweight exercises', 'Medium'),
('Powerlifting Program', 1, NULL, 'Designed for powerlifting enthusiasts', 'High'),
('CrossFit Challenge', NULL, 3, 'CrossFit-style workout for all fitness levels', 'High'),
('Pilates Sculpt', 4, NULL, 'Pilates routine for toning and sculpting', 'Low'),
('Functional Fitness', NULL, 1, 'Functional exercises for everyday movement', 'Medium'),
('CBUM Workout', 5, NULL, 'Military-style bootcamp for a total body burn', 'High'),
('HVVYTraining', NULL, 2, 'Circuit-style workout for cardiovascular and strength benefits', 'Medium'),
('Mindful Movement', 3, NULL, 'Slow, mindful movements for stress relief and relaxation', 'Low'),
('Agility and Speed', NULL, 4, 'Drills to improve agility and speed', 'High'),
('Stretch and Flex', 2, NULL, 'Stretching routine for flexibility and mobility', 'Low'),
('Kettlebell Conditioning', NULL, 5, 'Kettlebell exercises for strength and endurance', 'Medium'),
('Barre Fitness', 1, NULL, 'Barre-inspired workout for a full-body burn', 'Low'),
('TRX Total Body', NULL, 3, 'Total body workout using TRX suspension straps', 'Medium'),
('MMA Fitness', NULL, 1, 'Mixed martial arts-inspired workout for conditioning', 'High'),
('Cycling Challenge', 4, NULL, 'Indoor cycling program for cardio and leg strength', 'Medium'),
('Swim Workout', NULL, 2, 'Swimming drills for a full-body workout', 'Low'),
('Dance Cardio', 5, NULL, 'Dance-based cardio workout for fun and fitness', 'Low');


CREATE TABLE Exercise (
    ExerciseID INT PRIMARY KEY IDENTITY,
    ExerciseDescription VARCHAR(255),
    MachineRequired VARCHAR(50),
	Muscletargeted varchar(50)
);
INSERT INTO Exercise (ExerciseDescription, MachineRequired, MuscleTargeted)
VALUES 
('Bench Press', 'Bench Press Machine', 'Chest, Triceps'),
('Squats', 'Squat Rack', 'Legs, Glutes'),
('Pull-ups', 'Pull-up Bar', 'Back, Biceps'),
('Shoulder Press', 'Shoulder Press Machine', 'Shoulders, Triceps'),
('Deadlifts', 'Barbell, Plates', 'Back, Legs'),
('Bicep Curls', 'Dumbbells', 'Biceps, Forearms'),
('Tricep Dips', 'Parallel Bars', 'Triceps, Chest'),
('Leg Press', 'Leg Press Machine', 'Legs, Glutes'),
('Lat Pulldowns', 'Lat Pulldown Machine', 'Back, Shoulders'),
('Plank', 'None', 'Core'),
('Crunches', 'None', 'Abdominals'),
('Lunges', 'None', 'Legs, Glutes'),
('Chest Flyes', 'Chest Fly Machine', 'Chest, Shoulders'),
('Hammer Curls', 'Dumbbells', 'Biceps, Forearms'),
('Calf Raises', 'Calf Raise Machine', 'Calves'),
('Russian Twists', 'Medicine Ball', 'Obliques'),
('Hyperextensions', 'Hyperextension Bench', 'Lower Back'),
('Arnold Press', 'Dumbbells', 'Shoulders, Triceps'),
('Romanian Deadlifts', 'Barbell, Plates', 'Hamstrings, Lower Back'),
('Side Plank', 'None', 'Obliques'),
('Incline Bench Press', 'Bench Press Machine', 'Upper Chest, Shoulders'),
('Leg Curl', 'Leg Curl Machine', 'Hamstrings'),
('Seated Row', 'Row Machine', 'Back, Biceps'),
('Reverse Crunches', 'None', 'Lower Abs'),
('Front Raises', 'Dumbbells', 'Shoulders'),
('Box Jumps', 'Plyo Box', 'Legs, Glutes'),
('Dumbbell Pullover', 'Dumbbell', 'Back, Chest'),
('Seated Leg Press', 'Leg Press Machine', 'Legs, Glutes'),
('Mountain Climbers', 'None', 'Full Body'),
('Push-ups', 'None', 'Chest, Shoulders, Triceps'),
('Dumbbell Rows', 'Dumbbells', 'Back, Biceps'),
('Leg Extensions', 'Leg Extension Machine', 'Quadriceps'),
('Russian Twists', 'Medicine Ball', 'Obliques'),
('Plank to Push-up', 'None', 'Core, Chest, Shoulders'),
('Hamstring Curls', 'Hamstring Curl Machine', 'Hamstrings'),
('Dumbbell Lunges', 'Dumbbells', 'Legs, Glutes'),
('Shoulder Shrugs', 'Dumbbells', 'Shoulders, Trapezius'),
('Cable Crunches', 'Cable Machine', 'Abdominals'),
('Chest Press', 'Chest Press Machine', 'Chest, Shoulders, Triceps'),
('Barbell Rows', 'Barbell', 'Back, Biceps'),
('Calf Raises', 'Smith Machine', 'Calves'),
('Kettlebell Swings', 'Kettlebell', 'Legs, Glutes, Shoulders'),
('Side Lateral Raises', 'Dumbbells', 'Shoulders'),
('Hammer Strength Machine Chest Press', 'Hammer Strength Machine', 'Chest, Shoulders, Triceps'),
('Skull Crushers', 'E-Z Curl Bar', 'Triceps'),
('Seated Calf Raise', 'Calf Raise Machine', 'Calves'),
('Lateral Pull-downs', 'Lat Pulldown Machine', 'Back, Biceps'),
('Plank with Leg Lift', 'None', 'Core, Glutes'),
('Seated Leg Curl', 'Leg Curl Machine', 'Hamstrings'),
('Seated Shoulder Press', 'Shoulder Press Machine', 'Shoulders, Triceps'),
('Ab Rollout', 'Ab Roller', 'Abdominals');
SELECT *
FROM Gym
WHERE GymID NOT IN (SELECT GymID FROM ApprovedGyms);

CREATE TABLE WorkoutPlanBreakdown (
    WorkoutPlanID INT,
    ExerciseID INT,
    Sets INT,
    Reps INT,
    Day VARCHAR(20),
    PRIMARY KEY (WorkoutPlanID, ExerciseID),
    FOREIGN KEY (WorkoutPlanID) REFERENCES WorkoutPlan(PlanID),
    FOREIGN KEY (ExerciseID) REFERENCES Exercise(ExerciseID)
);
INSERT INTO WorkoutPlanBreakdown (WorkoutPlanID, ExerciseID, Sets, Reps, Day)
VALUES 
(1, 1, 4, 12, 'Monday'),
(1, 2, 3, 15, 'Monday'),
(1, 3, 3, 20, 'Wednesday'),
(2, 4, 4, 12, 'Tuesday'),
(2, 5, 3, 10, 'Tuesday'),
(3, 6, 4, 15, 'Thursday'),
(3, 7, 3, 12, 'Thursday'),
(4, 8, 4, 12, 'Friday'),
(4, 9, 3, 15, 'Friday'),
(5, 10, 3, 30, 'Saturday'),
(6, 11, 4, 12, 'Monday'),
(6, 12, 3, 15, 'Monday'),
(7, 13, 4, 15, 'Wednesday'),
(7, 14, 3, 12, 'Wednesday'),
(8, 15, 4, 12, 'Tuesday'),
(8, 16, 3, 10, 'Tuesday'),
(9, 17, 4, 15, 'Thursday'),
(9, 18, 3, 12, 'Thursday'),
(10, 19, 4, 12, 'Friday'),
(10, 20, 3, 15, 'Friday'),
(11, 21, 3, 30, 'Saturday'),
(12, 22, 4, 12, 'Monday'),
(12, 23, 3, 15, 'Monday'),
(13, 24, 4, 15, 'Wednesday'),
(13, 25, 3, 12, 'Wednesday'),
(14, 26, 4, 12, 'Tuesday'),
(14, 27, 3, 10, 'Tuesday'),
(15, 28, 4, 15, 'Thursday'),
(15, 29, 3, 12, 'Thursday'),
(16, 30, 4, 12, 'Friday'),
(16, 31, 3, 15, 'Friday'),
(17, 32, 3, 30, 'Saturday'),
(18, 33, 4, 12, 'Monday'),
(18, 34, 3, 15, 'Monday'),
(19, 35, 4, 15, 'Wednesday'),
(19, 36, 3, 12, 'Wednesday'),
(20, 37, 4, 12, 'Tuesday'),
(20, 38, 3, 10, 'Tuesday'),
(21, 39, 2, 15, 'Thursday'),
(21, 20, 3, 12, 'Thursday'),
(22, 21, 2, 12, 'Friday'),
(22, 27, 3, 15, 'Friday'),
(23, 23, 3, 30, 'Saturday'),
(22, 22, 2, 12, 'Monday'),
(22, 25, 3, 15, 'Monday'),
(25, 26, 2, 15, 'Wednesday'),
(25, 27, 3, 12, 'Wednesday'),
(26, 28, 2, 12, 'Tuesday'),
(26, 29, 3, 10, 'Tuesday'),
(27, 50, 2, 15, 'Thursday'),
(27, 1, 3, 12, 'Thursday'),
(28, 2, 2, 12, 'Friday'),
(28, 3, 3, 15, 'Friday'),
(29, 2, 3, 30, 'Saturday'),
(20, 5, 2, 12, 'Monday');


CREATE TABLE WorkoutsFollowedByMembers (
    PlanID INT,
    MemberID INT,
    FOREIGN KEY (PlanID) REFERENCES WorkoutPlan(PlanID),
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID),
	Primary Key (MemberID,PlanID)
);
INSERT INTO WorkoutsFollowedByMembers (PlanID, MemberID)
VALUES 
(1, 1), (2, 1), (3, 2), (4, 3), (5, 4), (6, 5), (7, 6), (8, 7), (9, 8), (10, 9),
(1, 10), (12, 11), (13, 12), (14, 13), (15, 14), (16, 15), (17, 16), (18, 17), (19, 18), (20, 19),
(2, 20), (22, 21), (23, 22), (24, 23), (25, 24), (26, 25), (27, 26), (28, 27), (29, 28), (30, 29),
(3, 30), (32, 35), (36, 22), (34, 33), (35, 34), (36, 31), (37, 36), (38, 37), (39, 38), (40, 39),
(4, 30), (32, 31), (33, 32), (33, 33), (35, 33), (36, 35), (37, 31), (38, 31), (39, 33), (30, 33);


CREATE TABLE TrainersBookings (
    TrainerID INT,
    MemberID INT,
    Feedback VARCHAR(255),
    Rating INT,
	Day varchar(255),
	Time varchar(255),
    PRIMARY KEY (MemberID, TrainerID),
    FOREIGN KEY (TrainerID) REFERENCES Trainer(TrainerID),
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);
INSERT INTO TrainersBookings (TrainerID, MemberID, Feedback, Rating)
VALUES (1, 1, 'Good trainer', 5), 
       (1, 2, 'Needs improvement', 3),  
       (2, 3, 'Excellent service', 5);  
INSERT INTO TrainersBookings (TrainerID, MemberID, Feedback, Rating, Day, Time) VALUES 
(2, 1, 'Great session', 4, 'Monday', '9:00'),
(3, 2, 'Satisfactory training', 3, 'Tuesday', '10:00'),
(1, 3, 'Awesome workout', 5, 'Wednesday', '11:00'),
(2, 4, 'Helpful advice', 4, 'Thursday', '12:00'),
(3, 5, 'Friendly trainer', 5, 'Friday', '13:00'),
(1, 6, 'Encouraging coach', 4, 'Saturday', '14:00'),
(2, 7, 'Effective routines', 4, 'Sunday', '15:00'),
(3, 8, 'Motivating atmosphere', 5, 'Monday', '16:00'),
(1, 9, 'Challenging but fun', 5, 'Tuesday', '17:00'),
(2, 10, 'Impressive progress', 4, 'Wednesday', '18:00'),
(3, 11, 'Expert guidance', 5, 'Thursday', '19:00'),
(1, 12, 'Results-driven approach', 5, 'Friday', '20:00'),
(2, 13, 'Professional training', 5, 'Saturday', '21:00'),
(3, 14, 'Flexible scheduling', 4, 'Sunday', '22:00'),
(1, 15, 'Positive reinforcement', 4, 'Monday', '23:00'),
(2, 16, 'Dedicated trainer', 5, 'Tuesday', '9:00'),
(3, 17, 'Knowledgeable coach', 5, 'Wednesday', '10:00'),
(1, 18, 'Effective communication', 4, 'Thursday', '11:00'),
(2, 19, 'Personalized workouts', 5, 'Friday', '12:00'),
(3, 20, 'Encouraging progress', 4, 'Saturday', '13:00'),
(1, 21, 'Motivated and inspiring', 5, 'Sunday', '14:00'),
(2, 22, 'Friendly and supportive', 4, 'Monday', '15:00'),
(3, 23, 'Expert advice', 5, 'Tuesday', '16:00'),
(1, 24, 'Attentive coaching', 5, 'Wednesday', '17:00'),
(2, 25, 'Effective training plans', 4, 'Thursday', '18:00'),
(3, 26, 'Safe and professional', 5, 'Friday', '19:00'),
(1, 27, 'Positive and encouraging', 4, 'Saturday', '20:00'),
(2, 28, 'Highly recommended', 5, 'Sunday', '21:00'),
(3, 29, 'Excellent results', 5, 'Monday', '22:00'),
(1, 30, 'Friendly atmosphere', 4, 'Tuesday', '23:00'),
(2, 31, 'Expert knowledge', 5, 'Wednesday', '9:00'),
(3, 32, 'Caring and attentive', 5, 'Thursday', '10:00'),
(1, 33, 'Dedicated to clients', 4, 'Friday', '11:00'),
(2, 34, 'Great motivator', 5, 'Saturday', '12:00'),
(3, 35, 'Professional approach', 4, 'Sunday', '13:00'),
(1, 36, 'Customized training', 5, 'Monday', '14:00'),
(2, 37, 'Helpful and supportive', 4, 'Tuesday', '15:00'),
(3, 38, 'Inspiring workouts', 5, 'Wednesday', '16:00'),
(1, 39, 'Expert instruction', 5, 'Thursday', '17:00'),
(2, 40, 'Attentive to needs', 4, 'Friday', '18:00'),
(3, 41, 'Committed to results', 5, 'Saturday', '19:00'),
(1, 42, 'Friendly and approachable', 4, 'Sunday', '20:00'),
(2, 43, 'Knowledgeable and friendly', 5, 'Monday', '21:00'),
(3, 44, 'Encouraging and supportive', 5, 'Tuesday', '22:00'),
(4, 45, 'Professional and motivating', 4, 'Wednesday', '23:00'),
(4, 46, 'Friendly and motivating', 5, 'Thursday', '9:00'),
(5, 47, 'Experienced and professional', 5, 'Friday', '10:00'),
(5, 48, 'Patient and encouraging', 4, 'Saturday', '11:00'),
(2, 49, 'Knowledgeable and motivating', 5, 'Sunday', '12:00'),
(3, 50, 'Committed to client success', 4, 'Monday', '13:00');



---------------------------------------------------------------------------dietplan



CREATE TABLE DietPlan (
    PlanID INT PRIMARY KEY IDENTITY,
    Name VARCHAR(255) ,
    CreatorTrainerID INT,
    CreatorMemberID INT,
    Purpose VARCHAR(255),
    FOREIGN KEY (CreatorTrainerID) REFERENCES Trainer(TrainerID),
    FOREIGN KEY (CreatorMemberID) REFERENCES Member(MemberID)
);
INSERT INTO DietPlan (Name, CreatorTrainerID, CreatorMemberID, Purpose)
VALUES 
('Vegan Diet Plan', 1, NULL, 'Weight Loss'),
('High Protein Diet', 2, 3, 'Muscle Gain'),
('Keto Diet Plan', 1, NULL, 'Weight Loss'),
('Paleo Diet', 2, 4, 'Muscle Gain'),
('Low Carb Diet', 3, NULL, 'Weight Loss'),
('Mediterranean Diet', 3, NULL, 'Heart Health'),
('Intermittent Fasting Plan', 1, 5, 'Weight Loss'),
('Vegetarian Meal Plan', 2, NULL, 'Healthy Lifestyle'),
('Whole30 Diet', 4, NULL, 'Detoxification'),
('Flexitariadasan Diet', 5, NULL, 'Balanced Nutrition'),
('DASH Diet', 3, 2, 'Blood Pressure Management'),
('Atkins Diet', 2, NULL, 'Low Carb'),
('Zone Diet', 4, NULL, 'Hormonal Balance'),
('MIND Diet', 1, 3, 'Brain Health'),
('South Beach Diet', 3, NULL, 'Weight Loss'),
('Low FODMAP Diet', 2, 4, 'Digestive Health'),
('Raw Food Diet', 4, NULL, 'Nutrient Density'),
('Carnivore Diet', 1, NULL, 'High Protein'),
('Flexitarian Diet', 3, NULL, 'Flexibility'),
('Anti-Inflammatory Diet', 2, NULL, 'Inflammation Reduction'),
('Alkaline Diet', 1, 2, 'pH Balance'),
('Cabbage Soup Diet', 4, NULL, 'Short-Term Weight Loss'),
('Noom Diet', 3, NULL, 'Behavioral Change'),
('Scarsdale Diet', 2, 3, 'Rapid Weight Loss'),
('Military Diet', 1, NULL, 'Short-Term Weight Loss'),
('Blood Type Diet', 4, 4, 'Personalized Nutrition'),
('HCG Diet', 3, NULL, 'Rapid Weight Loss'),
('Grapefruit Diet', 2, 5, 'Metabolism Boost'),
('Dukan Diet', 1, NULL, 'High Protein'),
('Pritikin Diet', 3, NULL, 'Heart Health'),
('Apple Cider Vinegar Diet', NULL, 2, 'Detoxification'),
('Nutrisystem Diet', 1, NULL, 'Convenience'),
('SlimFast Diet', 2, NULL, 'Meal Replacement'),
('Weight Watchers (WW) Diet', 3, NULL, 'Portion Control'),
('Mayo Clinic Diet', 4,NULL, 'Lifestyle Change'),
('Volumetrics Diet', 1, NULL, 'Feeling Full'),
('Jenny Craig Diet', 3, NULL, 'Convenience'),
('HMR Diet', NULL, 5, 'Meal Replacement'),
('Optavia Diet', 1, NULL, 'Portion Control'),
('Engine 2 Diet', 4, NULL, 'Plant-Based'),
('GOLO Diet', 3, NULL, 'Insulin Control'),
('Noodsam Diet', 2, 3, 'Behavioral Change'),
('Pescatarian Diet', 1, NULL, 'Seafood Focus'),
('Alkaline Diet', 3, NULL, 'pH Balance'),
('Cabbage Soup Diet', 2, 5, 'Short-Term Weight Loss'),
('Noom Diet', 1, NULL, 'Behavioral Change'),
('Scarsdale Diet', 3, NULL, 'Rapid Weight Loss'),
('Military Diet', 2, 2, 'Short-Term Weight Loss'),
('Blood Type Diet', 1, NULL, 'Personalized Nutrition'),
('Pritikin Diet', 3, NULL, 'Heart Health'),
('Apple Cider Vinegar Diet', 4, NULL, 'Detoxification'),
('Nutrisystem Diet', 1, NULL, 'Convenience'),
('Alkaline Diet', 3, NULL, 'pH Balance'),
('Cabbage Soup Diet', 2, NULL, 'Short-Term Weight Loss');

CREATE TABLE Meal (
    MealID INT PRIMARY KEY IDENTITY,
    PlanID INT,
    MealName VARCHAR(255),
	Calories VARCHAR(255),
	Protein VARCHAR(255),
    Carbs VARCHAR(255),
    Fat VARCHAR(255),
	AllergenName VARCHAR(255),
    FOREIGN KEY (PlanID) REFERENCES DietPlan(PlanID)
);
INSERT INTO Meal (PlanID, MealName, Calories, Protein, Carbs, Fat, AllergenName)
VALUES
(1, 'Chicken Steak', 300, 15, 40, 10, 'Peanut Allergy'),
(1, 'Pasta', 500, 20, 50, 20, 'Peanut Allergy'),
(1, 'Salmon', 400, 18, 45, 15, 'Peanut Allergy'),
(2, 'Omelette', 350, 25, 30, 10, 'Lactose'),
(2, 'Sandwich', 550, 30, 55, 25, 'Lactose'),
(2, 'Chicken Curry', 450, 22, 40, 20, 'Lactose'),
(3, 'Pancakes', 320, 18, 35, 15, 'Peanut Allergy'),
(3, 'Burger', 520, 25, 55, 25, 'Peanut Allergy'),
(3, 'Pizza', 420, 20, 45, 20, 'Peanut Allergy'),
(4, 'Scrambled Eggs', 330, 22, 33, 12, 'Lactose'),
(4, 'Grilled Chicken', 530, 27, 60, 22, 'Lactose'),
(4, 'Steak', 440, 24, 50, 18, 'Lactose'),
(5, 'Avocado Toast', 310, 20, 25, 15, 'Peanut Allergy'),
(5, 'Burrito', 510, 28, 45, 22, 'Peanut Allergy'),
(5, 'Sushi', 420, 23, 40, 20, 'Peanut Allergy'),
(6, 'French Toast', 340, 25, 35, 12, 'Lactose'),
(6, 'Pasta Carbonara', 540, 32, 60, 25, 'Lactose'),
(6, 'Chicken Alfredo', 450, 28, 50, 20, 'Lactose'),
(7, 'Waffles', 330, 20, 30, 15, 'Peanut Allergy'),
(7, 'Club Sandwich', 530, 25, 60, 22, 'Peanut Allergy'),
(7, 'Tacos', 440, 22, 50, 18, 'Peanut Allergy'),
(8, 'Frittata', 320, 18, 35, 12, 'Lactose'),
(8, 'Caesar Salad', 520, 23, 55, 20, 'Lactose'),
(8, 'Baked Chicken', 430, 20, 45, 18, 'Lactose'),
(9, 'Smoothie Bowl', 310, 15, 30, 10, 'Peanut Allergy'),
(9, 'Quinoa Salad', 510, 20, 60, 22, 'Peanut Allergy'),
(9, 'Stir Fry', 420, 18, 55, 20, 'Peanut Allergy'),
(10, 'Oatmeal', 330, 22, 35, 12, 'Lactose'),
(10, 'Chicken Wrap', 530, 25, 60, 22, 'Lactose'),
(10, 'Tofu Stir Fry', 440, 20, 45, 18, 'Lactose'),
(11, 'Pancakes', 310, 18, 30, 10, 'Peanut Allergy'),
(11, 'Sandwich', 510, 25, 55, 20, 'Peanut Allergy'),
(11, 'Pasta', 420, 20, 45, 18, 'Peanut Allergy'),
(12, 'Frittata', 330, 20, 35, 12, 'Lactose'),
(12, 'Salad', 530, 25, 60, 22, 'Lactose'),
(12, 'Grilled Salmon', 440, 20, 45, 18, 'Lactose'),
(13, 'Smoothie Bowl', 310, 15, 30, 10, 'Peanut Allergy'),
(13, 'Burrito Bowl', 510, 20, 60, 22, 'Peanut Allergy'),
(13, 'Teriyaki Chicken', 420, 18, 55, 20, 'Peanut Allergy'),
(14, 'Oatmeal', 330, 22, 35, 12, 'Lactose'),
(14, 'Chicken Salad', 530, 25, 60, 22, 'Lactose'),
(14, 'Shrimp Pasta', 440, 20, 45, 18, 'Lactose'),
(15, 'Pancakes', 310, 18, 30, 10, 'Peanut Allergy'),
(15, 'Sandwich', 510, 25, 55, 20, 'Peanut Allergy'),
(15, 'Pasta', 420, 20, 45, 18, 'Peanut Allergy'),
(16, 'Frittata', 330, 20, 35, 12, 'Lactose'),
(16, 'Chicken Caesar Salad', 530, 25, 60, 22, 'Lactose'),
(16, 'Beef Stir Fry', 440, 20, 45, 18, 'Lactose'),
(17, 'Omelette', 310, 15, 30, 10, 'Peanut Allergy'),
(17, 'Burrito', 510, 20, 60, 22, 'Peanut Allergy');


CREATE TABLE DietPlanBreakdown (
    MealID INT,
    PlanID INT,
    PRIMARY KEY (MealID, PlanID),
    FOREIGN KEY (MealID) REFERENCES Meal(MealID),
    FOREIGN KEY (PlanID) REFERENCES DietPlan(PlanID)
);
INSERT INTO DietPlanBreakdown (MealID, PlanID)
VALUES 
(1, 1),
(2, 1),
(3, 1),
(4, 2),
(5, 2),
(6, 2),
(7, 3),
(8, 3),
(9, 3),
(10, 4);
INSERT INTO DietPlanBreakdown (MealID, PlanID)
VALUES 
(11, 4),
(12, 4),
(13, 5),
(14, 5),
(15, 5),
(16, 6),
(17, 6),
(18, 6),
(19, 7),
(20, 7),
(21, 7),
(22, 8),
(23, 8),
(24, 8),
(25, 9),
(26, 9),
(27, 9),
(28, 10),
(29, 10),
(30, 10),
(31, 11),
(32, 11),
(33, 11),
(34, 12),
(35, 12),
(36, 12),
(37, 13),
(38, 13),
(39, 13),
(40, 14),
(41, 14),
(42, 14),
(43, 15),
(44, 15),
(45, 15),
(46, 16),
(47, 16),
(48, 16),
(49, 17),
(50, 17);



CREATE TABLE DietFollowedByMembers (
    PlanID INT,
    MemberID INT,
    FOREIGN KEY (PlanID) REFERENCES DietPlan(PlanID),
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID),
	Primary Key (MemberID,PlanID)
);
INSERT INTO DietFollowedByMembers (PlanID, MemberID)
VALUES (1, 1),(2, 1),(3, 2)

INSERT INTO DietFollowedByMembers (PlanID, MemberID)
VALUES 
(4, 3),
(5, 4),
(6, 5),
(7, 6),
(8, 7),
(9, 8),
(10, 9),
(11, 10),
(12, 11),
(13, 12),
(14, 13),
(15, 14),
(16, 15),
(17, 16),
(18, 17),
(19, 18),
(20, 19),
(21, 20),
(22, 21),
(23, 22),
(24, 23),
(25, 24),
(26, 25),
(27, 26),
(28, 27),
(29, 28),
(30, 29),
(31, 30),
(32, 31),
(33, 32),
(34, 33),
(35, 34),
(36, 35),
(37, 36),
(38, 37),
(39, 38),
(40, 39),
(41, 40),
(42, 41),
(43, 42),
(44, 43),
(45, 44),
(46, 45),
(47, 46),
(48, 47);



-----------------------------------------------------------------------------Reports

--Details of members of one specific gym that get training from one specific trainer.
use GymManagementSystem
SELECT *
FROM Member
WHERE GymID = 1
  AND TrainerID = 1;

--3. Details of members across all gyms of a specific trainer that follow a diet plan
SELECT DISTINCT d.MemberID, m.Name AS MemberName, d.PlanID, dp.Name AS DietPlanName
FROM DietFollowedByMembers d
INNER JOIN Member m ON d.MemberID = m.MemberID
INNER JOIN DietPlan dp ON d.PlanID = dp.PlanID
INNER JOIN Trainer t ON dp.CreatorTrainerID = t.TrainerID
WHERE t.TrainerID = 1
and dp.Name = 'Vegan Diet Plan'; -- Specify the TrainerID here

--44. Count of members who will be using specific machines on a given day in a specific gym.
SELECT COUNT(DISTINCT wf.MemberID) AS MemberCount
FROM WorkoutPlan wp
JOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID
JOIN Exercise e ON wpb.ExerciseID = e.ExerciseID
JOIN WorkoutsFollowedByMembers wf ON wp.PlanID = wf.PlanID
JOIN Gym g ON wp.CreatorMemberID = g.GymID
WHERE wpb.Day = 'Monday' -- Specify the day here
AND e.MachineRequired = 'Bench Press Machine' -- Specify the machine here
AND g.GymID = 1; -- Specify the GymID here

--7List of workout plans that don�t require using a specific machine.
SELECT wp.Name AS WorkoutPlanName
FROM WorkoutPlan wp
WHERE NOT EXISTS (
    SELECT 1
    FROM WorkoutPlanBreakdown w
    JOIN Exercise e ON w.ExerciseID = e.ExerciseID
    WHERE w.WorkoutPlanID = wp.PlanID
    AND e.MachineRequired = 'Bench Press Machine' -- Specify the machine here
);

--9New membership data in last 3 months (Gym Owner).
SELECT *
FROM Member
WHERE DATEDIFF(MONTH, JoiningDate, GETDATE()) <= 3; -- Assuming JoiningDate is the column indicating when the member joined

--Comparison of total members in multiple gyms, in the past 6 months.
SELECT g.Name AS GymName, COUNT(DISTINCT m.MemberID) AS TotalMembers
FROM Gym g
JOIN Member m ON g.GymID = m.GymID
WHERE DATEDIFF(MONTH, m.JoiningDate, GETDATE()) <= 6
GROUP BY g.Name;



---------------------------------------------------------------------------AuditTables 

CREATE TRIGGER utr_AdminAudit ON dbo.Admin
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @AdminID INT;

    IF EXISTS (SELECT 1 FROM inserted)
    BEGIN
        SELECT @AdminID = i.AdminID FROM inserted i;
        
        INSERT INTO dbo.AdminAudit (AdminIDAudit, AdminID, Username, Name, Email, Password, ContactNumber, Role)
        SELECT 
            ISNULL((SELECT MAX(AdminIDAudit) FROM dbo.AdminAudit), 0) + ROW_NUMBER() OVER (ORDER BY (SELECT NULL)),
            i.AdminID,
            i.Username,
            i.Name,
            i.Email,
            i.Password,
            i.ContactNumber,
            i.Role
        FROM inserted i
        WHERE i.AdminID = @AdminID;
    END
END

GO

/****** Object:  Table [dbo].[Admin]    Script Date: 09/05/2024 8:39:31 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AdminAudit](
	[AdminIDAudit] [int] NOT NULL,
	[AdminID] [int] null,
	[Username] [varchar](50) NULL,
	[Name] [varchar](50) NULL,
	[Email] [varchar](100) NULL,
	[Password] [varchar](100) NULL,
	[ContactNumber] [varchar](20) NULL,
	[Role] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[AdminIDAudit] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO



--
CREATE TRIGGER utr_OwnerAudit ON dbo.Owner
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM inserted)
    BEGIN
        DECLARE @Action VARCHAR(10);
        SET @Action = CASE 
            WHEN EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
            ELSE 'INSERT'
        END;

        INSERT INTO dbo.OwnerAudit (Action, OwnerID, GymID, Name, Email, Username, Password, ContactNumber)
        SELECT 
            @Action,
            i.OwnerID,
            i.GymID,
            i.Name,
            i.Email,
            i.Username,
            i.Password,
            i.ContactNumber
        FROM inserted i;
    END
END

CREATE TABLE OwnerAudit (
    AuditID INT PRIMARY KEY IDENTITY,
    Action VARCHAR(10) NOT NULL, -- INSERT, UPDATE, LOGIN
    OwnerID INT,
    GymID INT,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Username VARCHAR(50),
    Password VARCHAR(100),
    ContactNumber VARCHAR(20),
    Timestamp DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_OwnerAudit_OwnerID FOREIGN KEY (OwnerID) REFERENCES Owner(OwnerID)
);

CREATE TRIGGER utr_TrainerAudit ON dbo.Trainer
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM inserted)
    BEGIN
        DECLARE @Action VARCHAR(10);
        SET @Action = CASE 
            WHEN EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
            ELSE 'INSERT'
        END;

        INSERT INTO dbo.TrainerAudit (Action, TrainerID, GymID, Name, Username, Password, Email, DOB, Address, ExperienceYears, AverageRating, CertificationLevel, ContactNo)
        SELECT 
            @Action,
            i.TrainerID,
            i.GymID,
            i.Name,
            i.Username,
            i.Password,
            i.Email,
            i.DOB,
            i.Address,
            i.ExperienceYears,
            i.AverageRating,
            i.CertificationLevel,
            i.ContactNo
        FROM inserted i;
    END
END


-- trainer
CREATE TABLE TrainerAudit (
    AuditID INT PRIMARY KEY IDENTITY,
    Action VARCHAR(10) NOT NULL, -- INSERT, UPDATE, LOGIN
    TrainerID INT,
    GymID INT,
    Name VARCHAR(255),
    Username VARCHAR(255),
    Password VARCHAR(255),
    Email VARCHAR(255),
    DOB VARCHAR(255),
    Address VARCHAR(255),
    ExperienceYears INT,
    AverageRating FLOAT,
    CertificationLevel VARCHAR(50),
    ContactNo VARCHAR(20),
    Timestamp DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_TrainerAudit_TrainerID FOREIGN KEY (TrainerID) REFERENCES Trainer(TrainerID)
);

-- member

CREATE TRIGGER utr_MemberAudit ON dbo.Member
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM inserted)
    BEGIN
        DECLARE @Action VARCHAR(10);
        SET @Action = CASE 
            WHEN EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
            ELSE 'INSERT'
        END;

        INSERT INTO dbo.MemberAudit (Action, MemberID, Name, Username, Password, Email, DOB, Address, Contact, EmergencyContact, Weight, Height, MembershipDuration, FitnessGoals, TrainerID, GymID)
        SELECT 
            @Action,
            i.MemberID,
            i.Name,
            i.Username,
            i.Password,
            i.Email,
            i.DOB,
            i.Address,
            i.Contact,
            i.EmergencyContact,
            i.Weight,
            i.Height,
            i.MembershipDuration,
            i.FitnessGoals,
            i.TrainerID,
            i.GymID
        FROM inserted i;
    END
END



CREATE TABLE MemberAudit (
    AuditID INT PRIMARY KEY IDENTITY,
    Action VARCHAR(10) NOT NULL, -- INSERT, UPDATE, LOGIN
    MemberID INT,
    Name VARCHAR(255),
    Username VARCHAR(255),
    Password VARCHAR(255),
    Email VARCHAR(255),
    DOB VARCHAR(255),
    Address VARCHAR(255),
    Contact VARCHAR(10),
    EmergencyContact VARCHAR(10),
    Weight DECIMAL(5, 2),
    Height DECIMAL(5, 2),
    MembershipDuration VARCHAR(50),
    FitnessGoals VARCHAR(255),
    TrainerID INT,
    GymID INT,
    Timestamp DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_MemberAudit_MemberID FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);

