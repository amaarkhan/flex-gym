﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace db_project
{
    public partial class Admin07_ApproveReq : Form
    {

        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;

        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Admin07_ApproveReq()
        {
            InitializeComponent();
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = true;

            // Set column header height
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void ApproveReq_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            // Hide the current form
            this.Hide();
            Form8 form = new Form8();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void allplans_Click(object sender, EventArgs e)
        {
                        string query = @"
            SELECT *
FROM Gym
WHERE GymID NOT IN (SELECT GymID FROM ApprovedGyms);";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = @"
            SELECT 
                g.GymID,
                g.Name AS GymName,
                g.Location,
                g.ContactNumber,
                g.Email,
                g.Facilities,
                g.MembershipPlans,
                g.ActiveMembersCount,
                g.Rating,
                g.Growth,
                g.FinancialPerformance,
                g.CustomerSatisfaction
            FROM 
                ApprovedGyms rg
                JOIN Gym g ON rg.GymID = g.GymID
                                                        ";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
                    string query = @"
            DELETE FROM RequestedGyms
            WHERE GymID = @GymID;";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@GymID", int.Parse(textBox1.Text)); // Assuming textbox1 contains the GymID
                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0)
                {
                    // Row deleted successfully
                    MessageBox.Show("Gym request aprroved.");
                }
                else
                {
                    // No rows deleted (GymID not found)
                    MessageBox.Show("Gym request not found.");
                }
            }
            query = @"
            Insert into ApprovedGyms(GymID)values (@GymID);";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@GymID", int.Parse(textBox1.Text)); // Assuming textbox1 contains the GymID
                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0)
                {
                    // Row deleted successfully
                    MessageBox.Show("Gym request aprroved.");
                }
                else
                {
                    // No rows deleted (GymID not found)
                    MessageBox.Show("Gym request not found.");
                }
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
