﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Trainer07_Workoutplanreport : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Trainer07_Workoutplanreport()
        {
            InitializeComponent();
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersHeight = 24;
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ReadOnly = true;
            dataGridView1.ColumnHeadersVisible = true;

            // Set column header height
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void Trainer07_Workoutplanreport_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void allplans_Click(object sender, EventArgs e)
        {
            int currentID = Convert.ToInt32( CurrentID); // Assuming CurrentID contains the current trainer's ID

            string connectionString = myConnectionString;
            string query = @"
SELECT wp.PlanID,wf.MemberID, wp.Name AS WorkoutPlanName
FROM TrainersBookings tb
INNER JOIN WorkoutsFollowedByMembers wf ON tb.MemberID = wf.MemberID
INNER JOIN WorkoutPlan wp ON wf.PlanID = wp.PlanID
WHERE tb.TrainerID = @CurrentID;
";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CurrentID", currentID);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Form9 form = new Form9();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int planID = Convert.ToInt32(textBox1.Text); // Assuming textBox1 contains the PlanID to update
            string trainerRemarks = textBox2.Text; // Set this to the new remarks value

            string connectionString = myConnectionString;
            string query = @"
UPDATE WorkoutPlan
SET TrainerRemarks = @TrainerRemarks
WHERE PlanID = @PlanID;
";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TrainerRemarks", trainerRemarks);
                command.Parameters.AddWithValue("@PlanID", planID);

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Trainer remarks updated successfully.");
                }
                else
                {
                    MessageBox.Show("No workout plan found with the specified PlanID.");
                }
            }
        }

    }
}
