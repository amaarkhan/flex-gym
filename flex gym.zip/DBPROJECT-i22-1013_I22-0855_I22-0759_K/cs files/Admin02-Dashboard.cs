﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Form8 : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;

        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Form8()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            this.Hide();
            Admin4_gymPerformances form = new Admin4_gymPerformances();

            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {// Hide the current form
            this.Hide();

            Admin07_ApproveReq form = new Admin07_ApproveReq();
            form.SetID(CurrentID);
            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            this.Hide();
            admin04_RevokeMemberships form = new admin04_RevokeMemberships();

            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            // Hide the current form
            this.Hide();
            Form2 form = new Form2();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }
    }
}
