﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class owner08_MemberReport : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentUsername ;
        public void SetUsername(string burh)
        {
            CurrentUsername = burh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public owner08_MemberReport()
        {
            InitializeComponent();
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Owner02_dashboard form = new Owner02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void owner08_MemberReport_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = @"
                UPDATE Member
                SET GymID = NULL
                WHERE MemberID IN (
                    SELECT MemberID
                    FROM WorkoutPlan
                    WHERE PlanID = @PlanID
                );";

            string connectionString = myConnectionString;

            // Assuming CurrentID is a string variable containing the PlanID value
            int planid = Convert.ToInt32(CurrentID);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", Convert.ToInt32(textBox1.Text));

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                MessageBox.Show("Successful");
            }


        }

        private void allplans_Click(object sender, EventArgs e)
        {
            string query = @"
        SELECT 
            Name,
            Weight ,
            Height,
            MembershipDuration ,
	        JoiningDate 
        FROM 
            Member";

            string connectionString = myConnectionString;
            
            // Assuming CurrentID is a string variable containing the PlanID value
            int planid = Convert.ToInt32(CurrentID);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", planid);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }
    }
}
