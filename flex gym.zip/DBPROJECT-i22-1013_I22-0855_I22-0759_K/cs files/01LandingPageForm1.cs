﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


using System.Data.SqlClient;
namespace db_project
{
    public partial class Form1 : Form
    {

        String myConnectionString = "Data Source=DESKTOP-QI6H2EA\\SQLEXPRESS;Initial Catalog=FlexTrainerInserted;Integrated Security=True;Encrypt=False";
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
         
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            this.Hide();
            Form2 form = new Form2();

            form.setConnectionString(myConnectionString);
            form.Show();
            
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form3 form = new Form3();

            form.setConnectionString(myConnectionString);
            form.Show();
        }
       

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form4 form = new Form4();

            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Trainer01_registation form = new Trainer01_registation();

            form.setConnectionString(myConnectionString);
            form.Show();
          
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            _2REPORTS form = new _2REPORTS();

            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           this.Hide();
            _04AuditTables form = new _04AuditTables();

            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
            string un = textBox1.Text;
            string pass = textBox2.Text;

            if (un == "" || pass == "")
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }


            SqlConnection conn = new SqlConnection(myConnectionString);
            conn.Open();
            SqlCommand cm;
            string query = "SELECT COUNT(*) FROM Admin WHERE Username = '" + un + "' AND Password = '" + pass + "'";
            cm = new SqlCommand(query, conn);
            int ret = (int)cm.ExecuteScalar();
            cm.Dispose();
            if (ret < 1)
            {

                //Check FOR owner
                query = "SELECT COUNT(*) FROM Owner WHERE Username = '" + un + "' AND Password = '" + pass + "'";
                cm = new SqlCommand(query, conn);
                ret = (int)cm.ExecuteScalar();
                cm.Dispose();
                if (ret < 1)
                {
                    //Check for Trainer
                    query = "SELECT COUNT(*) FROM Trainer WHERE Username = '" + un + "' AND Password = '" + pass + "'";
                    cm = new SqlCommand(query, conn);
                    ret = (int)cm.ExecuteScalar();
                    cm.Dispose();
                    if (ret < 1)
                    {
                        //Check for Member
                        query = "SELECT COUNT(*) FROM Member WHERE Username = '" + un + "' AND Password = '" + pass + "'";
                        cm = new SqlCommand(query, conn);
                        ret = (int)cm.ExecuteScalar();
                        cm.Dispose();
                        if (ret < 1)
                        {
                            MessageBox.Show("Invalid Credentials");
                            return;

                        }
                        else//login as Member
                        {
                            string CurrentUsername = textBox1.Text;
                            string connectionString = myConnectionString;
                            int memberID = 0;
                            using (SqlConnection conn1 = new SqlConnection(connectionString))
                            {

                                // Get GymID based on CurrentUsername
                                string queryGymID = "SELECT MemberID FROM Member WHERE Username = @Username";

                                conn1.Open();
                                using (SqlCommand cmd = new SqlCommand(queryGymID, conn))
                                {
                                    cmd.Parameters.AddWithValue("@Username", CurrentUsername);
                                    object result = cmd.ExecuteScalar();
                                    if (result != null)
                                    {
                                        memberID = Convert.ToInt32(result);
                                    }
                                }
                            }

                            MessageBox.Show("Login Successful");
                            this.Hide();

                            Member02_dashboard form = new Member02_dashboard();
                            form.SetID(Convert.ToString(memberID));
                            form.setConnectionString(myConnectionString);
                            form.Show();
                        }

                    }
                    else//login as trainer
                    {
                        string CurrentUsername = textBox1.Text;
                        string connectionString = myConnectionString;
                        int TrainerID = 0;
                        using (SqlConnection conn1 = new SqlConnection(connectionString))
                        {

                            // Get GymID based on CurrentUsername
                            string queryGymID = "SELECT TrainerID FROM Trainer WHERE Username = @Username";

                            conn1.Open();
                            using (SqlCommand cmd = new SqlCommand(queryGymID, conn))
                            {
                                cmd.Parameters.AddWithValue("@Username", CurrentUsername);
                                object result = cmd.ExecuteScalar();
                                if (result != null)
                                {
                                    TrainerID = Convert.ToInt32(result);
                                }
                            }
                        }


                        MessageBox.Show("Login Successful");
                        this.Hide();
                        Form9 form = new Form9();
                        form.SetID(Convert.ToString(TrainerID));
                        form.setConnectionString(myConnectionString);
                        form.Show();
                    }


                }
                else//login as owner 
                {
                    string CurrentUsername = textBox1.Text;
                    int OwnerID = 0;
                    using (SqlConnection conn1 = new SqlConnection(myConnectionString))
                    {

                        // Get OwnerID based on CurrentUsername
                        string queryOwnerID = "SELECT OwnerID FROM Owner WHERE Username = @Username";

                        conn1.Open();
                        using (SqlCommand cmd = new SqlCommand(queryOwnerID, conn))
                        {
                            cmd.Parameters.AddWithValue("@Username", CurrentUsername);
                            object result = cmd.ExecuteScalar();
                            if (result != null)
                            {
                                OwnerID = Convert.ToInt32(result);
                            }
                        }
                    }

                    MessageBox.Show("Login Successful");

                    /*Check if the Owner's gym is approved or not */
                    query = @"
                    SELECT *
                    FROM ApprovedGyms
                    WHERE GymID = (
                        SELECT GymID
                        FROM Owner
                        WHERE OwnerID = @OwnerID
                    )";
                    using (SqlConnection connection = new SqlConnection(myConnectionString))
                    {
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@OwnerID", OwnerID);
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        // Check if the gym row exists in ApprovedGyms
                        if (reader.HasRows)
                        {
                            this.Hide();
                            MessageBox.Show("Your gym is approved.");
                            Owner02_dashboard form = new Owner02_dashboard();
                            form.SetID(Convert.ToString(OwnerID));
                            form.setConnectionString(myConnectionString);
                            form.Show();
                        }
                        else
                        {
                            MessageBox.Show("Gym isn't Approved :(");
                        }
                        reader.Close();
                    }







                }
                return;
            }
            else//login as Admin
            {
                MessageBox.Show("Login Successful");
                this.Hide();
                //save the username and the adminid for the adminid write sql query 

                Form8 form = new Form8();

                form.setConnectionString(myConnectionString);
                form.Show();
            }

            // Close the SQL connection
            conn.Close();
        }
    }
}
