﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Trainer01_registation : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Trainer01_registation()
        {
            InitializeComponent();
        }

        private void Trainer01_registation_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            // Get values from text boxes
            string name = textBox1.Text;
            string username = textBox2.Text;
            string pass = textBox3.Text;
            string email = textBox4.Text;
            string dob = textBox5.Text;
            string address = textBox6.Text;
            int experienceYears = int.Parse(textBox7.Text);
            float averageRating = float.Parse(textBox8.Text);
            string contactNo = textBox9.Text;
            string certificationLevel = textBox10.Text;
            
            string checkQuery = "SELECT COUNT(*) FROM Admin WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Trainer WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Owner WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Member WHERE Username = @Username ";
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@Username", username);
                    SqlDataReader reader = checkCmd.ExecuteReader();

                    int totalUsernames = 0;
                    while (reader.Read())
                    {
                        totalUsernames += Convert.ToInt32(reader[0]);
                    }

                    reader.Close();

                    if (totalUsernames > 0)
                    {
                        MessageBox.Show("Username is already taken. Please choose a different username.");
                        return; // Exit the method without inserting the new record
                    }
                }
            }
            // Check if any field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(contactNo) || string.IsNullOrEmpty(certificationLevel))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }

            // Construct SQL query to insert values into the table
            string query = "INSERT INTO Trainer (Name, Username,  Password,Email, DOB, Address, ExperienceYears, AverageRating,  CertificationLevel, ContactNo) VALUES (@Name, @Username,  @Password,@Email, @DOB, @Address, @ExperienceYears, @AverageRating,  @CertificationLevel,@ContactNo)";

            // Create SQL command with parameters
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    // Add parameter values
                    cm.Parameters.AddWithValue("@Name", name);
                    cm.Parameters.AddWithValue("@Username", username);
                    cm.Parameters.AddWithValue("@Email", email);
                    cm.Parameters.AddWithValue("@Password", pass);
                    cm.Parameters.AddWithValue("@DOB", dob);
                    cm.Parameters.AddWithValue("@Address", address);
                    cm.Parameters.AddWithValue("@ExperienceYears", experienceYears);
                    cm.Parameters.AddWithValue("@AverageRating", averageRating);
                    cm.Parameters.AddWithValue("@ContactNo", contactNo);
                    cm.Parameters.AddWithValue("@CertificationLevel", certificationLevel);

                    // Execute query to insert values into the table
                    int ret = cm.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert trainer details");
                    }
                    else
                    {
                        MessageBox.Show("Trainer details inserted successfully");

                        this.Hide();
                        Form9 form = new Form9();
                        form.Show();

                        form.setConnectionString(myConnectionString);
                        //this.Close();
                    }
                }
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

    }
}
