﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace db_project
{
    public partial class Member03_addexcersise : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Member03_addexcersise()
        {
            InitializeComponent();
        }

        private void Member03_addexcersise_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;
            string query = "SELECT * FROM Exercise";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                string query = "INSERT INTO WorkoutPlanBreakdown (WorkoutPlanID, ExerciseID, Sets, Reps, Day) " +
                               "VALUES (@WorkoutPlanID, @ExerciseID, @Sets, @Reps, @Day)";

                using (SqlConnection conn = new SqlConnection(myConnectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Add parameters for each value to insert
                        cmd.Parameters.Add("@WorkoutPlanID", SqlDbType.Int);
                        cmd.Parameters.Add("@ExerciseID", SqlDbType.Int);
                        cmd.Parameters.Add("@Sets", SqlDbType.Int);
                        cmd.Parameters.Add("@Reps", SqlDbType.Int);
                        cmd.Parameters.Add("@Day", SqlDbType.VarChar);

                        // Get values from text boxes
                        int workoutPlanID = int.Parse(CurrentID);
                        int exerciseID = int.Parse(textBox1.Text);
                        int sets = int.Parse(textBox2.Text);
                        int reps = int.Parse(textBox3.Text);
                        string day = textBox4.Text;

                        // Set parameter values
                        cmd.Parameters["@WorkoutPlanID"].Value = workoutPlanID;
                        cmd.Parameters["@ExerciseID"].Value = exerciseID;
                        cmd.Parameters["@Sets"].Value = sets;
                        cmd.Parameters["@Reps"].Value = reps;
                        cmd.Parameters["@Day"].Value = day;

                        // Execute the insert
                        int ret = cmd.ExecuteNonQuery();

                        if (ret < 1) //if failed to insert
                        {
                            MessageBox.Show("Failed to insert workout plan details");
                        }
                        else
                        {
                            MessageBox.Show("Workout plan details inserted successfully");
                        }
                    }
                }
            

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //also display the ,workoutname and the excersise name ;
            string connectionString = myConnectionString;
            string query = @"
            SELECT 
                WP.Name AS WorkoutName,
                E.ExerciseDescription AS ExerciseName
            FROM 
                WorkoutPlanBreakdown WB
                JOIN WorkoutPlan WP ON WB.WorkoutPlanID = WP.PlanID
                JOIN Exercise E ON WB.ExerciseID = E.ExerciseID
            WHERE 
                WB.WorkoutPlanID = @PlanID";
            // Assuming CurrentID is a string variable containing the PlanID value
            int planid = Convert.ToInt32(CurrentID);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", planid);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member02_dashboard form = new Member02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }
    }
}
