﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace db_project
{
    public partial class member03_createWorkoutPlan : Form
    {
        
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public member03_createWorkoutPlan()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member02_dashboard form = new Member02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            // Get values from text boxes
            string name = textBox1.Text;
            string difficulty = textBox2.Text;
            int MemberID; // Assuming CurrentID contains the MemberID
            if (!int.TryParse(CurrentID, out MemberID))
            {
                MessageBox.Show("Invalid MemberID. Please enter a valid integer.");
                return;
            }

            // Check if any field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(difficulty))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }
            string query = "INSERT INTO WorkoutPlan (Name, CreatorMemberID, Difficulty) VALUES (@Name, @CreatorMemberID, @Difficulty)";
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@CreatorMemberID", MemberID);
                    cmd.Parameters.AddWithValue("@Difficulty", difficulty);
                    int ret = cmd.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert workout plan details");
                    }
                    else
                    {
                        int workoutplanid = -1;
                        MessageBox.Show("Workout plan details inserted successfully");
                        this.Hide();
                        Member03_addexcersise form = new Member03_addexcersise();

                        // Corrected part: Use cmd1 instead of cmd for the new command
                        query = "SELECT PlanID FROM WorkoutPlan WHERE Name = @Name"; ;
                        using (SqlCommand cmd1 = new SqlCommand(query, conn))
                        {
                            cmd1.Parameters.AddWithValue("@Name", name); // Use cmd1 here
                            object result = cmd1.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                            {
                                workoutplanid = Convert.ToInt32(result);
                            }
                        }

                        form.SetID(Convert.ToString(workoutplanid));

                        form.setConnectionString(myConnectionString);
                        form.Show();
                    }
                }
            }


        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }
    }
}
