﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Owner02_dashboard : Form
    {
        String myConnectionString;

        string CurrentID;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        public void SetID(string ID)
        {
            CurrentID = ID;
        }

        string CurrentUsername;
        public void SetUsername(string ownerID)
        {
            CurrentUsername = ownerID;
        }
        public Owner02_dashboard()
        {
            InitializeComponent();

        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            this.Hide();
            Owner03_TrianerReport form = new Owner03_TrianerReport();
            form.SetUsername(CurrentUsername);
            form.setConnectionString(myConnectionString);

            form.Show();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            owner05_AccountManagement form = new owner05_AccountManagement();
            form.SetUsername(CurrentUsername);
            form.SetID(CurrentID);
            form.setConnectionString(myConnectionString);

            form.Show();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            owner06_AddNewTrainer form = new owner06_AddNewTrainer();
            //Trainer01_registation form = new Trainer01_registation();
            form.setConnectionString(myConnectionString);

            form.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            owner08_MemberReport form = new owner08_MemberReport();
            form.SetUsername(CurrentUsername);
            form.setConnectionString(myConnectionString);

            form.Show();
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();  
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;

            // Modified SQL query to include the Gym name
            string query = @"
            SELECT g.Name AS GymName
            FROM Owner o
            JOIN Gym g ON o.GymID = g.GymID
            WHERE o.OwnerID = @currentID;
            ";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@currentID", CurrentID); // Add the CurrentID parameter to the command

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
