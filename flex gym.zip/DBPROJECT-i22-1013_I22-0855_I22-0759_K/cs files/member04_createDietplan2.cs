﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class member04_createDietplan2 : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
       
        public member04_createDietplan2()
        {
            InitializeComponent();
        }

        private void member04_createDietplan2_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            // Get values from text boxes
            string name = textBox1.Text;
            string goal = textBox2.Text;
            int MemberID; // Assuming CurrentID contains the MemberID
            if (!int.TryParse(CurrentID, out MemberID))
            {
                MessageBox.Show("Invalid MemberID. Please enter a valid integer.");
                return;
            }

            // Check if any field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(goal))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }
            string query = "INSERT INTO DietPLan (Name, CreatorMemberID, Purpose) VALUES (@Name, @CreatorMemberID, @goal)";
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@CreatorMemberID", MemberID);
                    cmd.Parameters.AddWithValue("@goal", goal);
                    int ret = cmd.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert workout plan details");
                    }
                    else
                    {
                        int DietPlanid = -1;
                        MessageBox.Show("Workout plan details inserted successfully");
                        this.Hide();
                        member05_adddietPLan  form = new member05_adddietPLan();

                        // Corrected part: Use cmd1 instead of cmd for the new command
                        query = "SELECT PlanID FROM DietPlan WHERE Name = @Name"; ;
                        using (SqlCommand cmd1 = new SqlCommand(query, conn))
                        {
                            cmd1.Parameters.AddWithValue("@Name", name); // Use cmd1 here
                            object result = cmd1.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                            {
                                DietPlanid = Convert.ToInt32(result);
                            }
                        }

                        form.SetID(Convert.ToString(DietPlanid));
                        form.setConnectionString(myConnectionString);
                        form.Show();
                    }
                }
            }
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Member02_dashboard form = new Member02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
