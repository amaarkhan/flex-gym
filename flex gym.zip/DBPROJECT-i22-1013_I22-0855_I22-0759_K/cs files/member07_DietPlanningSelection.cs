﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace db_project
{

    public partial class member07_DietPlanningSelection : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public member07_DietPlanningSelection()
        {
            InitializeComponent();

            comboBox1.Items.Add("Weight Loss");
            comboBox1.Items.Add("Muscle Gain");
            comboBox1.Items.Add("General Health");

            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersHeight = 24;
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = true;

            // Set column header height
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member02_dashboard form = new Member02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string planid = textBox1.Text;
            string memberid = CurrentID;

            string connectionString = myConnectionString;
            string query = "INSERT INTO DietFollowedByMembers (PlanID, MemberID) VALUES (@PlanID, @MemberID)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", planid);
                command.Parameters.AddWithValue("@MemberID", memberid);

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Diet plan assigned to member successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to assign Diet plan to member.");
                }
            }
        }

        private void allplans_Click(object sender, EventArgs e)
        {
            string connectionString = myConnectionString;
            string query = "\r\nSELECT \r\n    wp.Name AS DietPlanName,\r\n    COALESCE(t.Name, m.Name) AS CreatorName,\r\n    wp.Purpose AS Purpose,\r\n    e.MealName,\r\n    e.Calories,\r\n    e.Protein,\r\n    e.Carbs,\r\n    e.Fat,\r\n    e.AllergenName,\r\n    dp.MealID,\r\n    dp.PlanID\r\nFROM \r\n    DietPlan wp\r\n    LEFT JOIN Trainer t ON wp.CreatorTrainerID = t.TrainerID\r\n    LEFT JOIN Member m ON wp.CreatorMemberID = m.MemberID\r\n    JOIN DietPlanBreakdown dp ON wp.PlanID = dp.PlanID\r\n    JOIN Meal e ON dp.MealID = e.MealID";

            if (comboBox1.SelectedItem != null)
            {
                string selectedPurpose = comboBox1.SelectedItem.ToString();

                if (selectedPurpose == "Weight Loss")
                {
                    query += "\r\nWHERE \r\n    wp.Purpose = 'Weight Loss';";
                }
                else if (selectedPurpose == "Muscle Gain")
                {
                    query += "\r\nWHERE \r\n    wp.Purpose = 'Muscle Gain';";
                }
                else if (selectedPurpose == "General Health")
                {
                    query += "\r\nWHERE \r\n    wp.Purpose = 'General Health';";
                }
            }
            else
            {
                MessageBox.Show("Not selected");
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = @"
SELECT dp.Name AS DietPlanName
FROM DietPlan dp
JOIN DietFollowedByMembers dfm ON dp.PlanID = dfm.PlanID
WHERE dfm.MemberID = @CurrentID;
";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CurrentID", CurrentID); // Assuming CurrentID is the ID of the current member
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }

        }
    }
}
