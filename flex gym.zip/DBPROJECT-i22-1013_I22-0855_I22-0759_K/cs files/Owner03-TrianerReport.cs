﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Owner03_TrianerReport : Form
    {

        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentUsername;
        public void SetUsername(string burh)
        {
            CurrentUsername = burh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Owner03_TrianerReport()
        {
            InitializeComponent();
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void allplans_Click(object sender, EventArgs e)
        {
            string query = @"
        SELECT 
            TrainerID, 
            Name, 
            ExperienceYears, 
            AverageRating, 
            CertificationLevel 
        FROM 
            Trainer";
            string connectionString = myConnectionString;

            // Assuming CurrentID is a string variable containing the PlanID value
            int planid = Convert.ToInt32(CurrentID);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", planid);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = @"
                UPDATE Trainer
                SET GymID = NULL
                WHERE TrainerID IN (
                    SELECT TrainerID
                    FROM WorkoutPlan
                    WHERE PlanID = @PlanID
                );";

            string connectionString = myConnectionString;

            // Assuming CurrentID is a string variable containing the PlanID value
            int planid = Convert.ToInt32(CurrentID);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", Convert.ToInt32(textBox1.Text)) ;

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                MessageBox.Show("Successful");
            }


        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);

            form.Show();
        }
    }
}
