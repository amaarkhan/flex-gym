﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class owner06_AddNewTrainer : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentUsername;
        public void SetUsername(string burh)
        {
            CurrentUsername = burh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public owner06_AddNewTrainer()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Owner02_dashboard form = new Owner02_dashboard();
            form.Show();
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Owner02_dashboard form = new Owner02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show(); 
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;
            string query = "select TrainerID,Name,AverageRating,CertificationLevel,ContactNo,GymID as 'AssignedGym' from Trainer";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            string trainerID = textBox1.Text;
            string connectionString = myConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                // Get GymID based on CurrentUsername
                string queryGymID = "SELECT GymID FROM Owner WHERE OwnerID = @Username";
                int gymID = 0;
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(queryGymID, conn))
                {
                    cmd.Parameters.AddWithValue("@Username",Convert.ToInt32 (CurrentID));
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        gymID = Convert.ToInt32(result);
                    }
                }
            
                // Update the trainer table

                string queryInsert = "UPDATE Trainer SET GymID = @GymID WHERE TrainerID = @TrainerID;";
                using (SqlCommand cmd = new SqlCommand(queryInsert, conn))
                {
                    cmd.Parameters.AddWithValue("@GymID", gymID);
                    cmd.Parameters.AddWithValue("@TrainerID", Convert.ToInt32(trainerID));

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Trainer assigned to gym successfully");
                    }
                    else
                    {
                        MessageBox.Show("Failed to assign trainer to gym");
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void owner06_AddNewTrainer_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {


            // Get values from text boxes
            string name = textBox1.Text;
            string username = textBox2.Text;
            string pass = textBox3.Text;
            string email = textBox4.Text;
            string dob = textBox5.Text;
            string address = textBox6.Text;
            int experienceYears = int.Parse(textBox7.Text);
            float averageRating = float.Parse(textBox8.Text);
            string contactNo = textBox9.Text;
            string certificationLevel = textBox10.Text;

            string checkQuery = "SELECT COUNT(*) FROM Admin WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Trainer WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Owner WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Member WHERE Username = @Username ";
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@Username", username);
                    SqlDataReader reader = checkCmd.ExecuteReader();

                    int totalUsernames = 0;
                    while (reader.Read())
                    {
                        totalUsernames += Convert.ToInt32(reader[0]);
                    }

                    reader.Close();

                    if (totalUsernames > 0)
                    {
                        MessageBox.Show("Username is already taken. Please choose a different username.");
                        return; // Exit the method without inserting the new record
                    }
                }
            }
            // Check if any field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(contactNo) || string.IsNullOrEmpty(certificationLevel))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }

            // Construct SQL query to insert values into the table
            string query = "INSERT INTO Trainer (Name, Username,  Password,Email, DOB, Address, ExperienceYears, AverageRating,  CertificationLevel, ContactNo) VALUES (@Name, @Username,  @Password,@Email, @DOB, @Address, @ExperienceYears, @AverageRating,  @CertificationLevel,@ContactNo)";

            // Create SQL command with parameters
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    // Add parameter values
                    cm.Parameters.AddWithValue("@Name", name);
                    cm.Parameters.AddWithValue("@Username", username);
                    cm.Parameters.AddWithValue("@Email", email);
                    cm.Parameters.AddWithValue("@Password", pass);
                    cm.Parameters.AddWithValue("@DOB", dob);
                    cm.Parameters.AddWithValue("@Address", address);
                    cm.Parameters.AddWithValue("@ExperienceYears", experienceYears);
                    cm.Parameters.AddWithValue("@AverageRating", averageRating);
                    cm.Parameters.AddWithValue("@ContactNo", contactNo);
                    cm.Parameters.AddWithValue("@CertificationLevel", certificationLevel);
                    //cm.Parameters.AddWithValue("@CurrentID", CurrentID);

                    // Execute query to insert values into the table
                    int ret = cm.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert trainer details");
                    }
                    else
                    {
                        MessageBox.Show("Trainer details inserted successfully");

                    }
                }
            }
        }
    }
}
