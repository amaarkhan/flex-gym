﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Trainer05_Createworkout : Form
    {
        string CurrentID;
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Trainer05_Createworkout()
        {
            InitializeComponent();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form9 form = new Form9();
            form.Show();
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 form = new Form9();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
            this.Close();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click_1(object sender, EventArgs e)
        {
            // Get values from text boxes
            string name = textBox1.Text;
            string difficulty = textBox2.Text;
            int TrainerID; // Assuming CurrentID contains the TrainerID
            if (!int.TryParse(CurrentID, out TrainerID))
            {
                MessageBox.Show("Invalid TrainerID. Please enter a valid integer.");
                return;
            }

            // Check if any field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(difficulty))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }
            string query = "INSERT INTO WorkoutPlan (Name, CreatorTrainerID, Difficulty) VALUES (@Name, @CreatorTrainerID, @Difficulty)";
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@CreatorTrainerID", TrainerID);
                    cmd.Parameters.AddWithValue("@Difficulty", difficulty);
                    int ret = cmd.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert workout plan details");
                    }
                    else
                    {
                        int workoutplanid = -1;
                        MessageBox.Show("Workout plan details inserted successfully");
                        this.Hide();
                        Trainer06_addnewexcersise form = new Trainer06_addnewexcersise();

                        // Corrected part: Use cmd1 instead of cmd for the new command
                        query = "SELECT PlanID FROM WorkoutPlan WHERE Name = @Name"; ;
                        using (SqlCommand cmd1 = new SqlCommand(query, conn))
                        {
                            cmd1.Parameters.AddWithValue("@Name", name); // Use cmd1 here
                            object result = cmd1.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                            {
                                workoutplanid = Convert.ToInt32(result);
                            }
                        }

                        form.SetID(Convert.ToString(workoutplanid));
                        form.Show();
                    }
                }
            }

        }

        private void Trainer05_Createworkout_Load(object sender, EventArgs e)
        {

        }
    }
}
