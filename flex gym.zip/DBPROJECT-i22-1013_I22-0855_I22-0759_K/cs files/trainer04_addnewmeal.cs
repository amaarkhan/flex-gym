﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class trainer04_addnewmeal : Form
    {
        string CurrentID;
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        public void SetID(string ID)
        {
            CurrentID = ID;
        }

        public trainer04_addnewmeal()
        {
            InitializeComponent();
        }

        private void trainer04_addnewmeal_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;
            string query = "SELECT * FROM Meal";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string query = "INSERT INTO DietPlanBreakdown (PlanID, MealID) " +
                           "VALUES (@DietPlanID, @DietID)";

            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Add parameters for each value to insert
                    cmd.Parameters.Add("@DietPlanID", SqlDbType.Int);
                    cmd.Parameters.Add("@DietID", SqlDbType.Int);


                    int DietPlanID = int.Parse(CurrentID);
                    int DietID = int.Parse(textBox1.Text);

                    cmd.Parameters["@DietPlanID"].Value = DietPlanID;
                    cmd.Parameters["@DietID"].Value = DietID;

                    int ret = cmd.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert workout plan details");
                    }
                    else
                    {
                        MessageBox.Show("Workout plan details inserted successfully");
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = myConnectionString;
            string query = "SELECT MealID FROM DietPlanBreakdown WHERE PlanID = @PlanID";

            // Assuming CurrentID is a string variable containing the PlanID value
            int planid = Convert.ToInt32(CurrentID);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", planid);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }
    }
}
