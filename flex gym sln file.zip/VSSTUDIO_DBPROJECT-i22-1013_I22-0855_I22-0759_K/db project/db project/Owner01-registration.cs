﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace db_project
{
    public partial class Form4 : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        public Form4()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            // Get username and password from text boxes
            string name = textBox1.Text;
            string username = textBox2.Text;
            string email = textBox3.Text;
            string pass = textBox4.Text;
            string contactno = textBox5.Text;

            // Check if any field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(contactno))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }
            string checkQuery = "SELECT COUNT(*) FROM Admin WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Trainer WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Owner WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Member WHERE Username = @Username ";
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@Username", username);
                    SqlDataReader reader = checkCmd.ExecuteReader();

                    int totalUsernames = 0;
                    while (reader.Read())
                    {
                        totalUsernames += Convert.ToInt32(reader[0]);
                    }

                    reader.Close();

                    if (totalUsernames > 0)
                    {
                        MessageBox.Show("Username is already taken. Please choose a different username.");
                        return; // Exit the method without inserting the new record
                    }
                }
            }
            // Construct SQL query to insert values into the table
            string query = "INSERT INTO Owner (Name, Username, Email, Password, ContactNumber) VALUES (@Name, @Username, @Email, @Password, @ContactNumber)";

            // Create SQL command with parameters
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    // Add parameter values
                    cm.Parameters.AddWithValue("@Name", name);
                    cm.Parameters.AddWithValue("@Username", username);
                    cm.Parameters.AddWithValue("@Email", email);
                    cm.Parameters.AddWithValue("@Password", pass);
                    cm.Parameters.AddWithValue("@ContactNumber", contactno);

                    // Execute query to insert values into the table
                    int ret = cm.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert owner details");
                    }
                    else
                    {

                        MessageBox.Show("Owner details inserted successfully");
                        this.Hide();

                        Owner02_registerGym form = new Owner02_registerGym();

                        //find the currentID 
                         query = "SELECT OwnerID FROM Owner WHERE Username = @Username";
                        int ownerID;
                        using (SqlConnection connection = new SqlConnection(myConnectionString))
                        {
                            connection.Open();

                            // Get OwnerID based on the given Username
                            SqlCommand ownerCommand = new SqlCommand(query, connection);
                            ownerCommand.Parameters.AddWithValue("@Username", username);
                            ownerID = (int)ownerCommand.ExecuteScalar();
                        }

                        form.setConnectionString(myConnectionString);
                        form.SetID(Convert.ToString(ownerID));
                        form.Show();
                    }
                }
            }





        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);
            
            form.Show();

        }
    }
}
