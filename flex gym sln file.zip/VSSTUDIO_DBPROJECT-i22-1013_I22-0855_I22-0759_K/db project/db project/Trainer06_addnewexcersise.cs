﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Trainer06_addnewexcersise : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Trainer06_addnewexcersise()
        {
            InitializeComponent();
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersHeight = 24;
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = true;

            // Set column header height
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string query = "INSERT INTO WorkoutPlanBreakdown (WorkoutPlanID, ExerciseID, Sets, Reps, Day) " +
                           "VALUES (@WorkoutPlanID, @ExerciseID, @Sets, @Reps, @Day)";

            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Add parameters for each value to insert
                    cmd.Parameters.Add("@WorkoutPlanID", SqlDbType.Int);
                    cmd.Parameters.Add("@ExerciseID", SqlDbType.Int);
                    cmd.Parameters.Add("@Sets", SqlDbType.Int);
                    cmd.Parameters.Add("@Reps", SqlDbType.Int);
                    cmd.Parameters.Add("@Day", SqlDbType.VarChar);

                    // Get values from text boxes
                    int workoutPlanID = int.Parse(CurrentID);
                    int exerciseID = int.Parse(textBox1.Text);
                    int sets = int.Parse(textBox2.Text);
                    int reps = int.Parse(textBox3.Text);
                    string day = textBox4.Text;

                    // Set parameter values
                    cmd.Parameters["@WorkoutPlanID"].Value = workoutPlanID;
                    cmd.Parameters["@ExerciseID"].Value = exerciseID;
                    cmd.Parameters["@Sets"].Value = sets;
                    cmd.Parameters["@Reps"].Value = reps;
                    cmd.Parameters["@Day"].Value = day;

                    // Execute the insert
                    int ret = cmd.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert workout plan details");
                    }
                    else
                    {
                        MessageBox.Show("Workout plan details inserted successfully");
                    }
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;
            string query = "SELECT * FROM Exercise";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = myConnectionString;
            string query = "SELECT ExerciseID, Sets, Reps, Day FROM WorkoutPlanBreakdown WHERE WorkoutPlanID = @PlanID";

            // Assuming CurrentID is a string variable containing the PlanID value
            int planid = Convert.ToInt32(CurrentID);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", planid);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void Trainer06_addnewexcersise_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            trainer04_createDietPlan form = new trainer04_createDietPlan();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }
    }
}
