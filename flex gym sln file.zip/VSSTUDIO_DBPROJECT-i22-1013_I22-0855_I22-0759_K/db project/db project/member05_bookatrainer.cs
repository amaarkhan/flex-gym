﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace db_project
{
    public partial class member05_bookatrainer : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;

        public void SetID(string ID){
            CurrentID = ID;
        }
        public member05_bookatrainer()
        {
            InitializeComponent();
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersHeight = 24;
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = true;

            // Set column header height
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
            dataGridView2.RowsDefaultCellStyle = cellStyle;


        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member02_dashboard form = new Member02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void allplans_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;
            string query = "select TrainerID,Name,ExperienceYears,CertificationLevel,ContactNo from Trainer";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;
            string query = "SELECT TrainerID, AverageRating, Name\r\nFROM Trainer\r\nORDER BY AverageRating DESC;\r\n";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }



        }

        private void label7_Click(object sender, EventArgs e)
        {
            int trainerID = Convert.ToInt32(textBox2.Text);
            int memberID = Convert.ToInt32(CurrentID);

            string connectionString = myConnectionString;
            string query = "INSERT INTO TrainersBookings (TrainerID, MemberID) VALUES (@TrainerID, @MemberID)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TrainerID", trainerID);
                command.Parameters.AddWithValue("@MemberID", memberID);

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0){
                    MessageBox.Show("Booking added successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to add booking.");
                }
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;
            string query = "select * from TrainersBookings where MemberID = @CurrentID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CurrentID", CurrentID);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView2.DataSource = table;
            }
        }
    }
}
