﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Owner02_registerGym : Form
    {
        String myConnectionString;

        string CurrentID;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        public void SetID(string ID)
        {
            CurrentID = ID;
        }

        string CurrentUsername;
        public void SetUsername(string ownerID)
        {
            CurrentUsername = ownerID;
        }
        public Owner02_registerGym()

        {
            InitializeComponent();
        }


        private void allplans_Click(object sender, EventArgs e)
        {
            string query = @"
        SELECT g.GymID, g.Name, g.Location, g.ContactNumber, g.Email, g.Facilities, g.MembershipPlans, g.ActiveMembersCount, g.Rating
        FROM Gym g
        LEFT JOIN ApprovedGyms a ON g.GymID = a.GymID
        WHERE a.GymID IS NULL";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                // Assuming dataGridView1 is your DataGridView control
                dataGridView1.DataSource = table;
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {
            string query = "SELECT COUNT(*) FROM RequestedGyms WHERE GymID = @GymID";
            int gymID = Convert.ToInt32(textBox6.Text);
            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                connection.Open();

                // Check if the gym is already requested
                SqlCommand checkCommand = new SqlCommand(query, connection);
                checkCommand.Parameters.AddWithValue("@GymID", gymID);
                int count = (int)checkCommand.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("Gym is already waiting for approval.");
                    return;
                }

                // Insert the gym into RequestedGyms
                query = "INSERT INTO RequestedGyms (GymID) VALUES (@GymID)";
                SqlCommand insertCommand = new SqlCommand(query, connection);
                insertCommand.Parameters.AddWithValue("@GymID", gymID);
                insertCommand.ExecuteNonQuery();

                MessageBox.Show("Gym has been successfully requested.");
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        public void InsertIntoGym(string name, string location, string contactNumber, string email, string facilities, string membershipPlans, string activeMembersCountText, string ratingText, string growth)
        {
            

            string query = "SELECT ISNULL(MAX(GymID), 0) + 1 FROM Gym";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                connection.Open();

                // Get a unique GymID
                SqlCommand idCommand = new SqlCommand(query, connection);
                int gymID = (int)idCommand.ExecuteScalar();

                // Insert into Gym table
                query = "INSERT INTO Gym (GymID, OwnerID, Name, Location, ContactNumber, Email, Facilities, MembershipPlans, ActiveMembersCount, Rating, Growth) " +
                        "VALUES (@GymID, @OwnerID, @Name, @Location, @ContactNumber, @Email, @Facilities, @MembershipPlans, @ActiveMembersCount, @Rating, @Growth)";
                SqlCommand insertCommand = new SqlCommand(query, connection);
                insertCommand.Parameters.AddWithValue("@GymID", gymID);
                insertCommand.Parameters.AddWithValue("@OwnerID", CurrentID);
                insertCommand.Parameters.AddWithValue("@Name", textBox1.Text);
                insertCommand.Parameters.AddWithValue("@Location", textBox2.Text);
                insertCommand.Parameters.AddWithValue("@ContactNumber", textBox3.Text);
                insertCommand.Parameters.AddWithValue("@Email", textBox4.Text);
                insertCommand.Parameters.AddWithValue("@Facilities", textBox5.Text);
                insertCommand.Parameters.AddWithValue("@MembershipPlans", textBox7.Text);
                insertCommand.Parameters.AddWithValue("@ActiveMembersCount", Convert.ToDecimal(textBox8.Text));
                insertCommand.Parameters.AddWithValue("@Rating", Convert.ToDecimal(textBox9.Text));
                insertCommand.Parameters.AddWithValue("@Growth", textBox10.Text);
                insertCommand.ExecuteNonQuery();
                MessageBox.Show("Gym has been successfully added.");

                // Update the GymID of the Owner row
                query = "UPDATE Owner SET GymID = @GymID WHERE OwnerID = @OwnerID";
                SqlCommand updateCommand = new SqlCommand(query, connection);
                updateCommand.Parameters.AddWithValue("@GymID", gymID);
                updateCommand.Parameters.AddWithValue("@OwnerID", CurrentID);
                updateCommand.ExecuteNonQuery();
                MessageBox.Show("Owner Assigned Gym.");


                query = "INSERT INTO RequestedGyms (GymID, OwnerID) " +
                       "VALUES (@GymID, @OwnerID)";
                SqlCommand insertCommand3 = new SqlCommand(query, connection);
                insertCommand3.Parameters.AddWithValue("@GymID", gymID);
                insertCommand3.Parameters.AddWithValue("@OwnerID", CurrentID);
                insertCommand3.ExecuteNonQuery();
                MessageBox.Show("Gym Approval request sent.");
            }

        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            InsertIntoGym(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text, textBox7.Text, textBox8.Text, textBox9.Text);

            string query = @"
                    SELECT Status
                    FROM ApprovedGyms
                    WHERE GymID = (
                        SELECT GymID
                        FROM Owner
                        WHERE OwnerID = @OwnerID
                    )";
            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@OwnerID", Convert.ToInt32(CurrentID));
                connection.Open();
                object result = command.ExecuteScalar();

                // Check if the gym is approved
                if (result != null && result.ToString() == "Approved")
                {
                    this.Hide();
                    MessageBox.Show("Your gym is approved.");
                    Owner02_dashboard form = new Owner02_dashboard();
                    form.SetID(Convert.ToString(CurrentID));
                    form.setConnectionString(myConnectionString);
                    form.Show();
                }
                else
                {
                    MessageBox.Show("Gym isnt Approved :(");
                    this.Hide();
                    Form1 form = new Form1();
                    form.SetID(Convert.ToString(CurrentID));
                    form.setConnectionString(myConnectionString);
                    form.Show();
                }
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);

            form.Show();
        }
    }
}
