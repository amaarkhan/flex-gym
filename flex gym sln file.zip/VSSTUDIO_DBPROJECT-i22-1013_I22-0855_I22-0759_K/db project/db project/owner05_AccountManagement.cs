﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{

    public partial class owner05_AccountManagement : Form
    {

        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentUsername;
        public void SetUsername(string burh)
        {
            CurrentUsername = burh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public owner05_AccountManagement()
        {
            InitializeComponent();
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Owner02_dashboard form = new Owner02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

            string trainerID = textBox3.Text;
            string connectionString = myConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                
                string queryGymID = "SELECT GymID FROM Owner WHERE OwnerID = @CurrentID";
                int gymID = 0;
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(queryGymID, conn))
                {
                    cmd.Parameters.AddWithValue("@CurrentID", CurrentID);
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        gymID = Convert.ToInt32(result);
                    }
                }

                // Update the trainer table

                string queryInsert = "UPDATE Trainer SET GymID = @GymID WHERE TrainerID = @TrainerID;";
                using (SqlCommand cmd = new SqlCommand(queryInsert, conn))
                {
                    cmd.Parameters.AddWithValue("@GymID", DBNull.Value);
                    cmd.Parameters.AddWithValue("@TrainerID", trainerID);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Trainer REMOVED FRON gym successfully");
                    }
                    else
                    {
                        MessageBox.Show("Failed to REMOVE trainer to gym");
                    }
                }
            }
        }

        private void owner05_AccountManagement_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string queryGymID = @"
            SELECT GymID
            FROM Owner
            WHERE OwnerID = @OwnerID";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand commandGymID = new SqlCommand(queryGymID, connection);
                commandGymID.Parameters.AddWithValue("@OwnerID", CurrentID);
                connection.Open();
                int gymID = (int)commandGymID.ExecuteScalar();

                string queryMembers = @"
                SELECT TrainerID,Name 
                FROM Trainer
                WHERE GymID = @GymID";

                SqlCommand commandMembers = new SqlCommand(queryMembers, connection);
                commandMembers.Parameters.AddWithValue("@GymID", gymID);

                SqlDataAdapter adapter = new SqlDataAdapter(commandMembers);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
                    string queryGymID = @"
                    SELECT GymID
                    FROM Owner
                    WHERE OwnerID = @OwnerID";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand commandGymID = new SqlCommand(queryGymID, connection);
                commandGymID.Parameters.AddWithValue("@OwnerID", CurrentID);
                connection.Open();
                int gymID = (int)commandGymID.ExecuteScalar();

                string queryMembers = @"
SELECT *
FROM Member
WHERE GymID = @GymID";

                SqlCommand commandMembers = new SqlCommand(queryMembers, connection);
                commandMembers.Parameters.AddWithValue("@GymID", gymID);

                SqlDataAdapter adapter = new SqlDataAdapter(commandMembers);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }

        }

        private void AllTrainers_Click(object sender, EventArgs e)
        {
            string queryGymID = @"
            SELECT GymID
            FROM Owner
            WHERE OwnerID = @OwnerID";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand commandGymID = new SqlCommand(queryGymID, connection);
                commandGymID.Parameters.AddWithValue("@OwnerID", CurrentID);
                connection.Open();
                int gymID = (int)commandGymID.ExecuteScalar();

                string queryMembers = @"
                SELECT TrainerID,Name 
                FROM Trainer;";
                SqlCommand commandMembers = new SqlCommand(queryMembers, connection);
                commandMembers.Parameters.AddWithValue("@GymID", gymID);

                SqlDataAdapter adapter = new SqlDataAdapter(commandMembers);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void AllMembers_Click(object sender, EventArgs e)
        {
            string queryGymID = @"
SELECT GymID
FROM Owner
WHERE OwnerID = @OwnerID";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand commandGymID = new SqlCommand(queryGymID, connection);
                commandGymID.Parameters.AddWithValue("@OwnerID", CurrentID);
                connection.Open();
                int gymID = (int)commandGymID.ExecuteScalar();

                string queryMembers = @"
SELECT MemberID,Name 
FROM Member";

                SqlCommand commandMembers = new SqlCommand(queryMembers, connection);
                commandMembers.Parameters.AddWithValue("@GymID", gymID);

                SqlDataAdapter adapter = new SqlDataAdapter(commandMembers);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

            string trainerID = textBox3.Text;
            string connectionString = myConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                // Get GymID based on CurrentUsername
                string queryGymID = "SELECT GymID FROM Owner WHERE OwnerID = @CurrentID";
                int gymID = 0;
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(queryGymID, conn))
                {
                    cmd.Parameters.AddWithValue("@CurrentID", CurrentID);
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        gymID = Convert.ToInt32(result);
                    }
                }

                // Update the trainer table

                string queryInsert = "UPDATE Trainer SET GymID = @GymID WHERE TrainerID = @TrainerID;";
                using (SqlCommand cmd = new SqlCommand(queryInsert, conn))
                {
                    cmd.Parameters.AddWithValue("@GymID", gymID);
                    cmd.Parameters.AddWithValue("@TrainerID", trainerID);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Trainer assigned to gym successfully");
                    }
                    else
                    {
                        MessageBox.Show("Failed to assign trainer to gym");
                    }
                }
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

            string MemberID = textBox1.Text;
            string connectionString = myConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                // Get GymID based on CurrentUsername
                string queryGymID = "SELECT GymID FROM Owner WHERE OwnerID = @CurrentID";
                int gymID = 0;
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(queryGymID, conn))
                {
                    cmd.Parameters.AddWithValue("@CurrentID", CurrentID);
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        gymID = Convert.ToInt32(result);
                    }
                }

                // Update the Member table

                string queryInsert = "UPDATE Member SET GymID = @GymID WHERE MemberID = @MemberID;";
                using (SqlCommand cmd = new SqlCommand(queryInsert, conn))
                {
                    cmd.Parameters.AddWithValue("@GymID", gymID);
                    cmd.Parameters.AddWithValue("@MemberID", MemberID);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Member assigned to gym successfully");
                    }
                    else
                    {
                        MessageBox.Show("Failed to assign Member to gym");
                    }
                }
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

            string MemberID = textBox3.Text;
            string connectionString = myConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {


                string queryGymID = "SELECT GymID FROM Owner WHERE OwnerID = @CurrentID";
                int gymID = 0;
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(queryGymID, conn))
                {
                    cmd.Parameters.AddWithValue("@CurrentID", CurrentID);
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        gymID = Convert.ToInt32(result);
                    }
                }

                // Update the Member table

                string queryInsert = "UPDATE Member SET GymID = @GymID WHERE MemberID = @MemberID;";
                using (SqlCommand cmd = new SqlCommand(queryInsert, conn))
                {
                    cmd.Parameters.AddWithValue("@GymID", DBNull.Value);
                    cmd.Parameters.AddWithValue("@MemberID", MemberID);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Member REMOVED FROM gym successfully");
                    }
                    else
                    {
                        MessageBox.Show("Failed to REMOVE");
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
