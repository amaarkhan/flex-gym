﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Member07_Feedback : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Member07_Feedback()
        {
            InitializeComponent();
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersHeight = 24;
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = true;

            // Set column header height
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void label6_Click(object sender, EventArgs e)
        {

            // Assuming textbox1 contains the PlanID and currentid contains the MemberID
            string trainerid = textBox1.Text;
            int  rating  = Convert.ToInt32(textBox2.Text);
            string  feedback = textBox3.Text;
            string memberid = CurrentID;

            string connectionString = myConnectionString;
            string query = @"
            MERGE INTO TrainersBookings AS target
            USING (VALUES (@TrainerID, @MemberID, @Rating, @Feedback)) AS source (TrainerID, MemberID, Rating, Feedback)
            ON target.TrainerID = source.TrainerID AND target.MemberID = source.MemberID
            WHEN MATCHED THEN
                UPDATE SET Rating = source.Rating, Feedback = source.Feedback
            WHEN NOT MATCHED THEN
                INSERT (TrainerID, MemberID, Rating, Feedback) VALUES (source.TrainerID, source.MemberID, source.Rating, source.Feedback);
            SELECT @@ROWCOUNT";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TrainerID", trainerid);
                command.Parameters.AddWithValue("@MemberID", memberid);
                command.Parameters.AddWithValue("@Rating", rating);
                command.Parameters.AddWithValue("@Feedback", feedback);

                connection.Open();
                int rowsAffected = (int)command.ExecuteScalar();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Trainer booking updated/inserted successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to update/insert trainer booking.");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
                string connectionString = myConnectionString;
                string query = "SELECT * FROM TrainersBookings WHERE MemberID = @MemberID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@MemberID", CurrentID);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();

                    adapter.Fill(table);

                    dataGridView1.DataSource = table;
                }
            

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member02_dashboard form = new Member02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }
    }
}
