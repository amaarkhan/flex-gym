﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class trainer04_createDietPlan : Form
    {
        string CurrentID;
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public trainer04_createDietPlan()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string difficulty = textBox2.Text;
            int TrainerID; // Assuming CurrentID contains the TrainerID
            if (!int.TryParse(CurrentID, out TrainerID))
            {
                MessageBox.Show("Invalid TrainerID. Please enter a valid integer.");
                return;
            }

            // Check if any field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(difficulty))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }
            string query = "INSERT INTO DietPlan (Name, CreatorTrainerID, Difficulty) VALUES (@Name, @CreatorTrainerID, @Difficulty)";
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@CreatorTrainerID", TrainerID);
                    cmd.Parameters.AddWithValue("@Difficulty", difficulty);
                    int ret = cmd.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert Diet plan details");
                    }
                    else
                    {
                        int Dietplanid = -1;
                        MessageBox.Show("Diet plan details inserted successfully");
                        this.Hide();
                        Trainer06_addnewexcersise form = new Trainer06_addnewexcersise();

                        // Corrected part: Use cmd1 instead of cmd for the new command
                        query = "SELECT PlanID FROM DietPlan WHERE Name = @Name"; ;
                        using (SqlCommand cmd1 = new SqlCommand(query, conn))
                        {
                            cmd1.Parameters.AddWithValue("@Name", name); // Use cmd1 here
                            object result = cmd1.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                            {
                                Dietplanid = Convert.ToInt32(result);
                            }
                        }

                        form.SetID(Convert.ToString(Dietplanid));
                        form.Show();
                    }
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Form9 form = new Form9();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
