﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Form3 : Form
    {

        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        public Form3()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {


            // Get values from text boxes
            string name = textBox1.Text;
            string username = textBox2.Text;
            string pass = textBox3.Text;
            string email = textBox4.Text;
            string dob = textBox5.Text;
            string address = textBox6.Text;
            string contact = textBox7.Text;
            string emergencyContact = textBox8.Text;
            float weight = float.Parse(textBox9.Text);
            float height = float.Parse(textBox10.Text);
            string membershipDuration = textBox11.Text;
            string fitnessGoals = textBox13.Text;
            int gymID;
            if (!int.TryParse(textBox12.Text, out gymID))
            {
                // Handle the case where the conversion fails
                MessageBox.Show("Invalid GymID. Please enter a valid integer.");
                return;
            }

            // Now you can use the gymID variable in your SQL query
            // Check if the username exists in any of the tables
            string checkQuery = "SELECT COUNT(*) FROM Admin WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Trainer WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Owner WHERE Username = @Username " +
                                "UNION ALL " +
                                "SELECT COUNT(*) FROM Member WHERE Username = @Username ";
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@Username", username);
                    SqlDataReader reader = checkCmd.ExecuteReader();

                    int totalUsernames = 0;
                    while (reader.Read())
                    {
                        totalUsernames += Convert.ToInt32(reader[0]);
                    }

                    reader.Close();

                    if (totalUsernames > 0)
                    {
                        MessageBox.Show("Username is already taken. Please choose a different username.");
                        return; // Exit the method without inserting the new record
                    }
                }
            }
            // Check if any field is empty
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(contact) || string.IsNullOrEmpty(emergencyContact) || string.IsNullOrEmpty(membershipDuration) || string.IsNullOrEmpty(fitnessGoals))
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }

            // Construct SQL query to insert values into the table
            string query = "INSERT INTO Member (Name, Username, Password, Email, DOB, Address, Contact, EmergencyContact, Weight, Height, MembershipDuration, FitnessGoals, GymID,JoiningDate) VALUES (@Name, @Username, @Password, @Email, @DOB, @Address, @Contact, @EmergencyContact, @Weight, @Height, @MembershipDuration, @FitnessGoals, @GymID,@JoiningDate)";

            // Create SQL command with parameters
            using (SqlConnection conn = new SqlConnection(myConnectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Add parameter values
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", pass);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@DOB", dob);
                    cmd.Parameters.AddWithValue("@Address", address);
                    cmd.Parameters.AddWithValue("@Contact", contact);
                    cmd.Parameters.AddWithValue("@EmergencyContact", emergencyContact);
                    cmd.Parameters.AddWithValue("@Weight", weight);
                    cmd.Parameters.AddWithValue("@Height", height);
                    cmd.Parameters.AddWithValue("@MembershipDuration", membershipDuration);
                    cmd.Parameters.AddWithValue("@FitnessGoals", fitnessGoals);
                    cmd.Parameters.AddWithValue("@GymID", gymID);
                    cmd.Parameters.AddWithValue("@JoiningDate", DateTime.Today);

                    // Execute query to insert values into the table
                    int ret = cmd.ExecuteNonQuery();

                    if (ret < 1) //if failed to insert
                    {
                        MessageBox.Show("Failed to insert member details");
                    }
                    else
                    {
                        MessageBox.Show("Member details inserted successfully");


                        this.Hide();
                        Member02_dashboard form = new Member02_dashboard();
                        
                        int memberID = 0;
                        using (SqlConnection conn1 = new SqlConnection(myConnectionString))
                        {

                            // Get GymID based on CurrentUsername
                            string queryGymID = "SELECT MemberID FROM Member WHERE Username = @Username";

                            conn1.Open();
                            using (SqlCommand cmd1 = new SqlCommand(queryGymID, conn))
                            {
                                cmd1.Parameters.AddWithValue("@Username", textBox2.Text);
                                object result = cmd1.ExecuteScalar();
                                if (result != null)
                                {
                                    memberID = Convert.ToInt32(result);
                                }
                            }
                        }
                        form.setConnectionString(myConnectionString);
                        form.SetID(Convert.ToString(memberID));
                        form.Show();
                    }
                }
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {// Hide the current forms
                this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);
            form.Show();

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
