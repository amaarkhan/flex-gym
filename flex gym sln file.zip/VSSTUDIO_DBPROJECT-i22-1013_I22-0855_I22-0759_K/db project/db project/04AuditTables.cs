﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class _04AuditTables : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public _04AuditTables()
        {
            InitializeComponent();
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }
        private void LoadAuditData(string tableName)
        {
            string query = $"SELECT * FROM {tableName};";
            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }


        private void allplans_Click(object sender, EventArgs e)
        {
            LoadAuditData("AdminAudit");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadAuditData("OwnerAudit");  
        }

        private void button1_Click(object sender, EventArgs e)
        {
        
        LoadAuditData("TrainerAudit");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadAuditData("MemberAudit");
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);
            form.Show();
        }
    }
}
