﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace db_project
{
    public partial class member04_WorkoutReport : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public member04_WorkoutReport()
        {
            InitializeComponent();
            // Add items to the ComboBox
            comboBox1.Items.Add("Low");
            comboBox1.Items.Add("Medium");
            comboBox1.Items.Add("Hard");

            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersHeight = 24;
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = true;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;

            dataGridView2.RowsDefaultCellStyle = cellStyle;
        }

        private void WorkoutReport_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Member02_dashboard form = new Member02_dashboard();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
       
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void allplans_Click(object sender, EventArgs e)
        {
            string connectionString = myConnectionString;
            string query = "\r\nSELECT \r\n    CASE WHEN ROW_NUMBER() OVER (PARTITION BY wp.PlanID ORDER BY wp.PlanID) = 1 THEN wp.Name ELSE ''\r\n    END AS WorkoutPlanName,\r\n    CASE WHEN ROW_NUMBER() OVER (PARTITION BY wp.PlanID ORDER BY wp.PlanID) = 1 THEN COALESCE(t.Name, m.Name) ELSE ''\r\n    END AS CreatorName,wp.PlanID,wp.Difficulty, e.ExerciseDescription,\r\n    e.MuscleTargeted,\r\n    wpb.Sets,\r\n    wpb.Reps,\r\n    wpb.Day\r\nFROM \r\n    WorkoutPlan wp\r\n    LEFT JOIN Trainer t ON wp.CreatorTrainerID = t.TrainerID\r\n    LEFT JOIN Member m ON wp.CreatorMemberID = m.MemberID\r\n    JOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID\r\n    JOIN Exercise e ON wpb.ExerciseID = e.ExerciseID";
            

            if (comboBox1.SelectedItem != null)
            {

                string selectedDifficulty = comboBox1.SelectedItem.ToString();

                if (selectedDifficulty == "Low\n")
                {
                    MessageBox.Show(selectedDifficulty);
                    query += "\r\nWHERE \r\n    wp.Difficulty = 'Low';";
                }
                else if (selectedDifficulty == "Medium")
                {
                    query += "\r\nWHERE \r\n    wp.Difficulty = 'Medium';";
                }
                else if (selectedDifficulty == "Hard")
                {
                    query += "\r\nWHERE \r\n    wp.Difficulty = 'Hard';";
                }
            }
            else MessageBox.Show("Notselected");

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {

            string connectionString = myConnectionString;
            string query = "\r\nSELECT \r\n    CASE  WHEN ROW_NUMBER() OVER (PARTITION BY wp.PlanID ORDER BY wp.PlanID) = 1 THEN wp.Name ELSE ''\r\n    END AS WorkoutPlanName,\r\n    CASE  WHEN ROW_NUMBER() OVER (PARTITION BY wp.PlanID ORDER BY wp.PlanID) = 1 THEN COALESCE(t.Name, m.Name) ELSE ''\r\n    END AS CreatorName,\r\n    e.ExerciseDescription,\r\n  wp.Difficulty,  e.MuscleTargeted,\r\n    wpb.Sets,\r\n    wpb.Reps,\r\n    wpb.Day\r\nFROM \r\n    WorkoutPlan wp\r\n    LEFT JOIN Trainer t ON wp.CreatorTrainerID = t.TrainerID\r\n    LEFT JOIN Member m ON wp.CreatorMemberID = m.MemberID\r\n    JOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID\r\n    JOIN Exercise e ON wpb.ExerciseID = e.ExerciseID\r\nWHERE \r\n    wp.Difficulty = 'Low';";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {


            string connectionString = myConnectionString;
            string query = "\r\nSELECT \r\n    CASE  WHEN ROW_NUMBER() OVER (PARTITION BY wp.PlanID ORDER BY wp.PlanID) = 1 THEN wp.Name ELSE ''\r\n    END AS WorkoutPlanName,\r\n    CASE  WHEN ROW_NUMBER() OVER (PARTITION BY wp.PlanID ORDER BY wp.PlanID) = 1 THEN COALESCE(t.Name, m.Name) ELSE ''\r\n    END AS CreatorName,\r\n  wp.Difficulty,  e.ExerciseDescription,\r\n   wp.Difficulty,  e.MuscleTargeted,\r\n    wpb.Sets,\r\n    wpb.Reps,\r\n    wpb.Day\r\nFROM \r\n    WorkoutPlan wp\r\n    LEFT JOIN Trainer t ON wp.CreatorTrainerID = t.TrainerID\r\n    LEFT JOIN Member m ON wp.CreatorMemberID = m.MemberID\r\n    JOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID\r\n    JOIN Exercise e ON wpb.ExerciseID = e.ExerciseID\r\nWHERE \r\n    wp.Difficulty = 'High';";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string planid = textBox1.Text;
            string memberid = CurrentID;

            string connectionString =   myConnectionString;
            string query = "INSERT INTO WorkoutsFollowedByMembers (PlanID, MemberID) VALUES (@PlanID, @MemberID)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PlanID", planid);
                command.Parameters.AddWithValue("@MemberID", memberid);

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Workout plan assigned to member successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to assign workout plan to member.");
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string query = @"
            SELECT 
                wp.Name AS 'Workout Plan Name',
                wp.TrainerRemarks
            FROM 
                WorkoutsFollowedByMembers wf
                JOIN WorkoutPlan wp ON wf.PlanID = wp.PlanID
            WHERE 
                wf.MemberID = @CurrentID;";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CurrentID", CurrentID); // Assuming CurrentID is the ID of the current member
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);
                dataGridView2.DataSource = table;
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string query = @"
            SELECT 
                CASE WHEN ROW_NUMBER() OVER (PARTITION BY wp.PlanID ORDER BY wp.PlanID) = 1 THEN wp.Name ELSE '' END AS WorkoutPlanName,
                CASE WHEN ROW_NUMBER() OVER (PARTITION BY wp.PlanID ORDER BY wp.PlanID) = 1 THEN COALESCE(t.Name, m.Name) ELSE '' END AS CreatorName,
                wp.Difficulty, e.ExerciseDescription, e.MuscleTargeted,
                wpb.Sets, wpb.Reps, wpb.Day
            FROM 
                WorkoutsFollowedByMembers wf
                JOIN WorkoutPlan wp ON wf.PlanID = wp.PlanID
                LEFT JOIN Trainer t ON wp.CreatorTrainerID = t.TrainerID
                LEFT JOIN Member m ON wp.CreatorMemberID = m.MemberID
                JOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID
                JOIN Exercise e ON wpb.ExerciseID = e.ExerciseID
            WHERE 
                wf.MemberID = @CurrentID;";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CurrentID", CurrentID); // Assuming CurrentID is the ID of the current member
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView2.DataSource = table;
            }

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string query = @"
            SELECT 
                wp.Name AS WorkoutPlanName,
                COALESCE(t.Name, m.Name) AS CreatorName,
                wp.Difficulty,
                e.ExerciseDescription,
                e.MuscleTargeted,
                wpb.Sets,
                wpb.Reps,
                wpb.Day,
                CONVERT(INT, wp.WorkoutDuration) AS WorkoutDuration
            FROM 
                WorkoutPlan wp
                LEFT JOIN Trainer t ON wp.CreatorTrainerID = t.TrainerID
                LEFT JOIN Member m ON wp.CreatorMemberID = m.MemberID
                JOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID
                JOIN Exercise e ON wpb.ExerciseID = e.ExerciseID
            ORDER BY
                CONVERT(INT, wp.WorkoutDuration) ASC;";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }

        }
    }
}
