﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class Member02_dashboard : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;

        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Member02_dashboard()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            this.Hide();
            member03_createWorkoutPlan form = new member03_createWorkoutPlan();
            form.SetID(CurrentID);

            form.setConnectionString(myConnectionString);
            
            form.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void ComboBox1_SelectedIndex(object sender, EventArgs e)
        {
            //a.Text=comboBox1.Text;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            member04_WorkoutReport form = new member04_WorkoutReport();
            form.SetID(CurrentID);
            form.setConnectionString(myConnectionString);

            form.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            
          
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            member07_DietPlanningSelection form = new member07_DietPlanningSelection();
            form.SetID(CurrentID);
            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            this.Hide();
            member05_bookatrainer form = new member05_bookatrainer();
            form.SetID(CurrentID);

            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void linkLabel6_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            this.Hide();
            Member07_Feedback form = new Member07_Feedback();
            form.SetID(CurrentID);

            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form3 form = new Form3();

            form.setConnectionString(myConnectionString);
            form.setConnectionString(myConnectionString);
            //form.SetID(CurrentID);
            form.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Member02_dashboard_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            //member07_CreateDietplan form = new member07_CreateDietplan();
            member04_createDietplan2 form = new member04_createDietplan2();
            form.SetID(CurrentID);
            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = myConnectionString;

            string query = @"
SELECT g.Name
FROM Member t
JOIN Gym g ON t.GymID = g.GymID;
";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }
    }
}
