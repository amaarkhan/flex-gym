﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace db_project
{
    public partial class _03_NewReports : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public _03_NewReports()
        {
            InitializeComponent();  // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
               
        }
        private void DisplayQueryResults(string query)
        {

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }

        }
        private void view_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("\r\nSELECT * FROM Member WHERE MemberID NOT IN (SELECT CreatorMemberID FROM WorkoutPlan WHERE CreatorMemberID IS NOT NULL)");
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT * FROM Trainer WHERE TrainerID IN (SELECT CreatorTrainerID FROM WorkoutPlan WHERE Difficulty = 'Medium');\r\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT * FROM WorkoutPlan WHERE PlanID IN (SELECT TOP 1 WorkoutPlanID FROM WorkoutPlanBreakdown ORDER BY Sets DESC);\r\n");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT wp.*, e.*\r\nFROM WorkoutPlan wp\r\nJOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID\r\nJOIN Exercise e ON wpb.ExerciseID = e.ExerciseID\r\nWHERE CHARINDEX(',', e.MuscleTargeted) > 0;\r\n");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT * FROM Exercise WHERE MuscleTargeted = 'Legs';\r\n");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT wp.*\r\nFROM WorkoutPlan wp\r\nJOIN Trainer t ON wp.CreatorTrainerID = t.TrainerID\r\nWHERE t.CertificationLevel = 'Expert';\r\n");
        }

        private void _03_NewReports_Load(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT * FROM Member WHERE JoiningDate > '2022-01-01';\r\n");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT * \r\nFROM Member \r\nWHERE DATEDIFF(YEAR, DOB, GETDATE()) BETWEEN 20 AND 30;\r\n");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT wp.*\r\nFROM WorkoutPlan wp\r\nJOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID\r\nJOIN Exercise e ON wpb.ExerciseID = e.ExerciseID\r\nWHERE wp.Difficulty = 'easy' AND e.MachineRequired IS NOT NULL;\r\n");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT TOP 1 TrainerID, AVG(Rating) AS AvgRating\r\nFROM TrainersBookings\r\nGROUP BY TrainerID\r\nORDER BY AVG(Rating) DESC;\r\n");
            /* private void DisplayQueryResults(string query)
        {

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }

        }*/

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            // Hide the current form
            this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }
    }
}
