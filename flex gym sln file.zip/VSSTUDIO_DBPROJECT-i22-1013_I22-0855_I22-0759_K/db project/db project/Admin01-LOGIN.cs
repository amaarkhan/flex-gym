﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace db_project
{
    public partial class Form2 : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;

        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public Form2()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            
            // Get username and password from text boxes
            string un = textBox1.Text;
            string pass = textBox3.Text;

            // Check if username or password is empty
            if (un == "" || pass == "")
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }


            SqlConnection conn = new SqlConnection(myConnectionString);
            conn.Open();
            SqlCommand cm;// Create SQL command
            // Construct SQL query to check credentials
            string query = "SELECT COUNT(*) FROM Admin WHERE Username = '" + un + "' AND Password = '" + pass + "'";
            cm = new SqlCommand(query, conn);
            int ret = (int)cm.ExecuteScalar();// Execute query and get result
            cm.Dispose();
            if (ret < 1) //if correct
            {
                MessageBox.Show("Invalid Credentials");
                return;
            }
            else{
                MessageBox.Show("Login Successful");
                this.Hide();

                //save the username, and the c
                Form8 form = new Form8();
                form.setConnectionString(myConnectionString);
                form.Show();
                Close();
            }

            // Close the SQL connection
            conn.Close();

            
            


            
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            // Hide the current form
            this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
