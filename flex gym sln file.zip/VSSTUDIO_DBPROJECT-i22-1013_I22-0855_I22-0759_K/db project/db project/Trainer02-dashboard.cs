﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace db_project
{
    public partial class Form9 : Form
    {
        string CurrentID;
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        public void SetID(string ID){
            CurrentID = ID;
        }
        public Form9()
        {
            InitializeComponent();
            

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            trainer03_appointment_managment form = new trainer03_appointment_managment();

            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID );
            form.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Hide the current form
            this.Hide();
            Trainer05_Createworkout form = new Trainer05_Createworkout();

            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Trainer07_Feedback form = new Trainer07_Feedback();
            form.SetID(CurrentID);
            form.setConnectionString(myConnectionString);
            form.Show();

        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.SetID(CurrentID);
            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void label15_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();

            form.setConnectionString(myConnectionString); form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
            
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            trainer04_createDietPlan form = new trainer04_createDietPlan();
            form.SetID(CurrentID);

            form.setConnectionString(myConnectionString);
            form.Show();
            this.Close();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Trainer07_Workoutplanreport form = new Trainer07_Workoutplanreport();
            form.SetID(CurrentID);

            form.setConnectionString(myConnectionString);
            form.Show();
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Trainer06_view_dietplan form = new Trainer06_view_dietplan();
            form.SetID(CurrentID);

            form.setConnectionString(myConnectionString);
            form.Show();
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = @"
    SELECT g.Name AS GymName
    FROM Trainer t
    JOIN Gym g ON t.GymID = g.GymID
    WHERE t.TrainerID = @currentID;
";

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@currentID", CurrentID); // Assuming CurrentID is the TrainerID

                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    string gymName = result.ToString();
                    MessageBox.Show($"Trainer is assigned to {gymName}.");
                }
                else
                {
                    MessageBox.Show("Trainer is not assigned to a gym.");
                }
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
