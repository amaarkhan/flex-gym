﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace db_project
{
    public partial class trainer03_appointment_managment : Form
    {

        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public trainer03_appointment_managment()
        {
            InitializeComponent();
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ColumnHeadersHeight = 24;
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = true;

            // Set column header height
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form9 form = new Form9();
            form.Show();
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 form = new Form9();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();
        }

        private void allplans_Click(object sender, EventArgs e)
        {
            string connectionString = myConnectionString;
            string query = "SELECT * FROM TrainersBookings WHERE TrainerID = @TrainerID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TrainerID", CurrentID);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                // Assuming dataGridView1 is the name of your DataGridView
                dataGridView1.DataSource = table;
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Assuming CurrentID contains the current trainer's ID
            int trainerID = Convert.ToInt32(CurrentID);
            int memberID = Convert.ToInt32(textBox1.Text);
            string day = textBox2.Text;
            string time = textBox3.Text;

            // Assuming Rating and Feedback are constant for this operation
            int rating = 4; // Example rating
            string feedback = "Good"; // Example feedback

            string connectionString = myConnectionString;
            string query = @"
            MERGE INTO TrainersBookings AS target
            USING (VALUES (@TrainerID, @MemberID, @Rating, @Feedback, @Day, @Time)) AS source (TrainerID, MemberID, Rating, Feedback, Day, Time)
            ON target.TrainerID = source.TrainerID AND target.MemberID = source.MemberID
            WHEN MATCHED THEN
                UPDATE SET Rating = source.Rating, Feedback = source.Feedback, Day = source.Day, Time = source.Time
            WHEN NOT MATCHED THEN
                INSERT (TrainerID, MemberID, Rating, Feedback, Day, Time) VALUES (source.TrainerID, source.MemberID, source.Rating, source.Feedback, source.Day, source.Time);
            SELECT @@ROWCOUNT";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TrainerID", trainerID);
                command.Parameters.AddWithValue("@MemberID", memberID);
                command.Parameters.AddWithValue("@Rating", rating);
                command.Parameters.AddWithValue("@Feedback", feedback);
                command.Parameters.AddWithValue("@Day", day);
                command.Parameters.AddWithValue("@Time", time);

                connection.Open();
                int rowsAffected = (int)command.ExecuteScalar();
                connection.Close();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record updated/inserted successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to update/insert record.");
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void trainer03_appointment_managment_Load(object sender, EventArgs e)
        {

        }
    }
}
