﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_project
{
    public partial class _2REPORTS : Form
    {
        String myConnectionString;
        public void setConnectionString(string bruh)
        {
            myConnectionString = bruh;
        }
        string CurrentID;
        public void SetID(string ID)
        {
            CurrentID = ID;
        }
        public _2REPORTS()
        {
            InitializeComponent();
            // Set row default cell style
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = Color.FromArgb(0, 0, 64);
            cellStyle.Font = new Font("Microsoft Sans Serif", 7.8f);
            cellStyle.ForeColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = cellStyle;

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void DisplayQueryResults(string query)
        {

            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {

                SqlCommand command = new SqlCommand(query, connection);


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }

        }
        private void view_Click(object sender, EventArgs e)
        {

        }

        private void view_Click_1(object sender, EventArgs e)
        {

            string query = @"SELECT * FROM Member WHERE GymID = @GymID AND TrainerID = @TrainerID;";
            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@GymID", textBox1.Text);
                command.Parameters.AddWithValue("@TrainerID", textBox2.Text);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = @"SELECT * FROM Member WHERE GymID = @GymID AND MemberID IN (SELECT MemberID FROM DietFollowedByMembers WHERE PlanID = @PlanID);";
            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@GymID", textBox4.Text);
                command.Parameters.AddWithValue("@PlanID", textBox3.Text);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            string query = @"SELECT COUNT(DISTINCT wf.MemberID) AS MemberCount
                    FROM WorkoutPlan wp
                    JOIN WorkoutPlanBreakdown wpb ON wp.PlanID = wpb.WorkoutPlanID
                    JOIN Exercise e ON wpb.ExerciseID = e.ExerciseID
                    JOIN WorkoutsFollowedByMembers wf ON wp.PlanID = wf.PlanID
                    JOIN Gym g ON wp.CreatorMemberID = g.GymID
                    --WHERE wpb.Day = @day 
                    AND e.MachineRequired = @machinerequired -- Specify the machine here
                    ";
            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                ///command.Parameters.AddWithValue("@day", );
                command.Parameters.AddWithValue("@machinerequired", "Dumbbell");
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string query = @"SELECT DISTINCT d.MemberID, m.Name AS MemberName, d.PlanID, dp.Name AS DietPlanName
                    FROM DietFollowedByMembers d
                    INNER JOIN Member m ON d.MemberID = m.MemberID
                    INNER JOIN DietPlan dp ON d.PlanID = dp.PlanID
                    INNER JOIN Trainer t ON dp.CreatorTrainerID = t.TrainerID
                    WHERE t.TrainerID = @TrainerID
                    AND dp.PlanID = @ID; ";
            using (SqlConnection connection = new SqlConnection(myConnectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TrainerID", Convert.ToInt32(textBox6.Text));
                command.Parameters.AddWithValue("@ID", Convert.ToInt32( textBox5.Text));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT * FROM DietPlan WHERE PlanID IN (SELECT PlanID FROM Meal WHERE AND TRY_CAST(Calories AS DECIMAL(5, 2)) < 500);");
        }


        private void button8_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT *\r\nFROM Member\r\nWHERE DATEDIFF(MONTH, JoiningDate, GETDATE()) <= 3; ");

        }

        private void button7_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT * FROM DietPlan WHERE PlanID NOT IN (SELECT PlanID FROM Meal WHERE AllergenName = 'Peanuts');");

        }

        private void button6_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT wp.Name AS WorkoutPlanName\r\nFROM WorkoutPlan wp\r\nWHERE NOT EXISTS (\r\n    SELECT 1\r\n    FROM WorkoutPlanBreakdown w\r\n    " +
                "JOIN Exercise e ON w.ExerciseID = e.ExerciseID\r\n    WHERE w.WorkoutPlanID = wp.PlanID\r\n    AND e.MachineRequired = 'Bench Press Machine' -- Specify the machine here\r\n);");

        }

        private void button5_Click(object sender, EventArgs e)
        {

            DisplayQueryResults("SELECT * FROM DietPlan WHERE PlanID IN (SELECT PlanID FROM Meal GROUP BY PlanID HAVING SUM(TRY_CAST(Carbs AS DECIMAL(5, 2)) ) < 300);");

        }

        private void button9_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT g.Name AS GymName, COUNT(DISTINCT m.MemberID) AS TotalMembers" +
                "\r\nFROM Gym g\r\nJOIN Member m ON g.GymID = m.GymID\r\nWHERE DATEDIFF(MONTH, m.JoiningDate, GETDATE()) <= 6\r\nGROUP BY g.Name;\r\n\r\n");

        }

        private void label8_Click(object sender, EventArgs e)
        {
            DisplayQueryResults("SELECT * FROM DietPlan WHERE PlanID NOT IN (SELECT PlanID FROM Meal WHERE AllergenName = 'Peanuts');");

        }
        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            _03_NewReports form = new _03_NewReports();
            form.setConnectionString(myConnectionString);
            form.SetID(CurrentID);
            form.Show();

        }

        private void _2REPORTS_Load(object sender, EventArgs e)
        {

        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.setConnectionString(myConnectionString);
            form.Show();
        }
    }
}
